// Submenu-capable menu system for Bennys
let menuOpen = false;
let currentMenu = 'main'; // 'main' or a mod type
let cursor = 0;
let menuStack = []; // Track menu history
let cursorStack = []; // Track cursor position per menu level

const menuList = document.getElementById('menu-list');
const menuTitle = document.getElementById('menu-title');
const menuSub = document.getElementById('menu-sub');

// Main menu categories - populated on menu open
let mainMenu = [];

// Mods for each category
let modsForCategory = {};

// Fetch categories from server
async function loadMainMenu() {
    return new Promise((resolve) => {
        fetch('https://bennys/getVehicleData', { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                mainMenu = data.categories || [];
                resolve();
            })
            .catch(() => resolve());
    });
}

// Fetch mods for a specific category
async function loadModsForType(modType, wheelType = null, finishType = null) {
    return new Promise((resolve) => {
        let cacheKey = modType;
        if (wheelType !== null) cacheKey += `::${wheelType}`;
        if (finishType !== null) cacheKey += `::${finishType}`;
        
        if (modsForCategory[cacheKey]) {
            resolve(modsForCategory[cacheKey]);
            return;
        }

        const body = { modType: modType };
        if (wheelType !== null) body.wheelType = wheelType;
        if (finishType !== null) body.finishType = finishType;

        fetch('https://bennys/getModsForType', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        })
                .then(r => r.json())
                .then(data => {
                    const mods = data.mods || [];
                    // if server provided debug info, attach it separately under the cache key
                    if (data.debug) {
                        mods.__debug = data.debug;
                    }
                    // store under the cache key including wheel type and finish type so they are cached separately
                    modsForCategory[cacheKey] = mods;
                    resolve(modsForCategory[cacheKey]);
                })
            .catch(err => {
                console.error('[bennys] fetch error:', err);
                resolve([]);
            });
    });
}

// Build menu based on current state
async function buildMenu() {
    menuList.innerHTML = '';
    // Only reset cursor to 0 if we don't have a saved position for this menu
    if (!(currentMenu in cursorStack)) {
        cursor = 0;
    } else {
        cursor = cursorStack[currentMenu] || 0;
    }
    
    let items = [];
    let title = '';
    let subtitle = '';
    
    // helper to parse currentMenu which may include a wheelType suffix like 'wheels::4' or finishType like 'paint::gloss'
    function parseCurrentMenu(key) {
        if (!key) return { base: key, wheelType: null, finishType: null };
        if (key.indexOf('::') !== -1) {
            const parts = key.split('::');
            return { base: parts[0], wheelType: parts[1] || null, finishType: parts[2] || null };
        }
        return { base: key, wheelType: null, finishType: null };
    }

    if (currentMenu === 'main') {
        items = mainMenu;
        title = 'Customize your vehicle';
        subtitle = 'Choose a category';
    } else {
        // currentMenu may be like 'wheels' or 'wheels::4' when a wheel type was selected
        // or 'paint::primary::gloss' for paint with channel and finish
        const parsed = parseCurrentMenu(currentMenu);
            const baseType = parsed.base;
            const currentWheelType = parsed.wheelType;
            const currentFinishType = parsed.finishType;
        const mods = modsForCategory[currentMenu] || [];
        // ensure mod items report the base modType (so applyMod sends 'wheels', not 'wheels::4')
        items = mods.map(mod => ({
            id: `mod_${mod.index}`,
            name: mod.name,
            modType: baseType,
            modIndex: mod.index,
            // prefer the submenu's wheelType (parsed from currentMenu) so variants are tagged correctly
            // NOTE: use explicit undefined check, not || operator, because wheelType 0 is falsy!
            wheelType: (currentWheelType !== null && currentWheelType !== undefined) ? currentWheelType : (mod.wheelType !== undefined ? mod.wheelType : null),
            finishType: (currentFinishType !== null && currentFinishType !== undefined) ? currentFinishType : (mod.finishType !== undefined ? mod.finishType : null),
            isPaintChannel: mod.isPaintChannel || false,
            isPaintFinish: mod.isPaintFinish || false,
            isWheelType: mod.isWheelType || false,
            isInfo: mod.isInfo || false
        }));

        // Find category name using the base type
        const catData = mainMenu.find(m => m.id === baseType);
        title = catData ? catData.name : 'Mods';
        subtitle = 'Select a modification';
    }
    
    menuTitle.textContent = title;
    menuSub.textContent = subtitle;
    
    items.forEach((item, idx) => {
        const li = document.createElement('li');
        li.textContent = item.name;
        li.dataset.id = item.id;
        li.dataset.index = idx;

        // If server marked this item as active/applied, render the persistent badge
        if (item.active) {
            try {
                const badge = document.createElement('span');
                badge.className = 'applied-badge';
                badge.textContent = item.name + ' applied';
                li.appendChild(badge);
            } catch (e) {}
        }
        
        if (item.modType) {
            // This is a mod option
            if (item.isPaintChannel) {
                // paint channel entry (primary/secondary/etc) — load finish options for this channel
                li.onclick = async () => {
                    cursorStack[currentMenu] = idx; // Save cursor position before leaving
                    // push to menu stack and load finish options for this channel
                    menuStack.push(currentMenu);
                    // set currentMenu to include the paint channel
                    currentMenu = `${item.modType}::${item.wheelType}`;
                    const mods = await loadModsForType(item.modType, item.wheelType);
                    buildMenu();
                };
            } else if (item.isPaintFinish) {
                // paint finish entry (gloss/matte) — load colors for this finish
                li.onclick = async () => {
                    cursorStack[currentMenu] = idx; // Save cursor position before leaving
                    // push to menu stack and load colors for this finish type
                    menuStack.push(currentMenu);
                    // set currentMenu to include the paint channel and finish type
                    currentMenu = `${item.modType}::${item.wheelType}::${item.finishType}`;
                    const mods = await loadModsForType(item.modType, item.wheelType, item.finishType);
                    buildMenu();
                };
            } else if (item.isWheelType) {
                // wheel type entry — load variants for this wheel type
                li.onclick = async () => {
                    cursorStack[currentMenu] = idx; // Save cursor position before leaving
                    // push to menu stack and load wheel variants for this type
                    menuStack.push(currentMenu);
                    // set currentMenu to the cache key used by loadModsForType so that the
                    // specific variants for this wheel type are displayed (e.g. 'wheels::4')
                    currentMenu = `${item.modType}::${item.wheelType}`;
                    const mods = await loadModsForType(item.modType, item.wheelType);
                                // if the server returned debug info, show a friendly info entry instead
                                if (mods && mods.__debug && mods.__debug.probeCount !== undefined && mods.__debug.probeCount <= 0) {
                                    const dbg = mods.__debug;
                                    mods.unshift({ index: -2, name: `No variants (requestedType ${dbg.requestedType}, probe ${dbg.probeCount})`, isInfo: true });
                                    modsForCategory[`${item.modType}::${item.wheelType}`] = mods;
                                }
                    buildMenu();
                };
            } else if (item.isInfo) {
                // informational entry - do nothing on click
                li.classList.add('info');
            } else {
                li.onclick = () => { 
                    cursor = idx; 
                    updateSelection(); 
                    applyMod(item.modType, item.modIndex, item.wheelType, item.finishType);

                    // Clear any previous applied badges within this menu (keep UI tidy)
                    try {
                        const prevBadges = menuList.querySelectorAll('.applied-badge');
                        prevBadges.forEach(b => b.remove());
                    } catch (e) {}

                    // Add a small 'Applied' badge to the clicked item so player sees which option applied
                    try {
                        const badge = document.createElement('span');
                        badge.className = 'applied-badge';
                        // Prefer a descriptive message like 'Engine level 4 applied' when possible
                        badge.textContent = `${item.name} applied`;
                        li.appendChild(badge);
                    } catch (e) {}

                    // Visual feedback: highlight the applied item briefly
                    li.style.backgroundColor = '#00ff00';
                    li.style.color = '#000000';
                    setTimeout(() => {
                        li.style.backgroundColor = '';
                        li.style.color = '';
                    }, 300);
                };
            }
        } else {
            // This is a category
            li.onclick = () => { 
                cursorStack[currentMenu] = idx; // Save cursor position before leaving
                enterCategory(item.id); 
            };
        }
        
        menuList.appendChild(li);
    });
    
    updateSelection();
}

// Enter a category submenu
async function enterCategory(modType) {
    menuStack.push(currentMenu);
    // set currentMenu to the base modType; the loadModsForType may set a more specific
    // cache key (e.g. wheels::4) when the user selects a wheel type
    currentMenu = modType;
    await loadModsForType(modType);
    buildMenu();
}

// Go back to previous menu
function goBack() {
    if (menuStack.length > 0) {
        cursorStack[currentMenu] = cursor; // Save current cursor before leaving
        currentMenu = menuStack.pop();
        buildMenu();
    } else {
        closeBennysMenu();
    }
}

function updateSelection() {
    const lis = menuList.querySelectorAll('li');
    lis.forEach(li => li.classList.remove('selected'));
    const current = lis[cursor];
    if (current) {
        current.classList.add('selected');
        // Keep the selected item visible in the scroll container
        current.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
}

function moveCursor(delta) {
    const lis = menuList.querySelectorAll('li');
    cursor += delta;
    if (cursor < 0) cursor = 0;
    if (cursor >= lis.length) cursor = lis.length - 1;
    updateSelection();
}

// Apply a mod modification
function applyMod(modType, modIndex, wheelType = null, finishType = null) {
    const body = { modType: modType, modIndex: modIndex };
    if (wheelType !== null && wheelType !== undefined) body.wheelType = wheelType;
    if (finishType !== null && finishType !== undefined) body.finishType = finishType;
    fetch('https://bennys/applyMod', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    }).catch(err => console.error('applyMod error', err));
    // Show persistent applied status in the NUI so the user can see the change
    try {
        showStatus('✓ Applied!');
    } catch (e) {
        // ignore if UI function is unavailable for some reason
    }
}

async function showBennysMenu() {
    menuOpen = true;
    await loadMainMenu();
    currentMenu = 'main';
    menuStack = [];
    cursorStack = {};
    document.getElementById('bennys-menu').classList.remove('hidden');
    buildMenu();
}

function showStatus(text) {
    const el = document.getElementById('menu-status');
    if (!el) return;
    el.textContent = text;
    el.classList.remove('hidden');
}

function hideStatus() {
    const el = document.getElementById('menu-status');
    if (!el) return;
    el.classList.add('hidden');
}

function closeBennysMenu() {
    menuOpen = false;
    document.getElementById('bennys-menu').classList.add('hidden');
    hideStatus();
    fetch('https://bennys/closeMenu', { method: 'POST' }).catch(() => {});
}

// Listen to NUI open/close events
window.addEventListener('message', (event) => {
    const data = event.data;
    if (data.type === 'toggle') {
        if (data.show) showBennysMenu();
        else closeBennysMenu();
    } else if (data.type === 'vehicleChanged') {
        // Clear cached mod lists so we request fresh data for the new vehicle
        modsForCategory = {};
        // If menu is open, close it to avoid stale data
        if (menuOpen) closeBennysMenu();
    }
});

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (!menuOpen) return;
    
    if (e.key === 'ArrowDown') { 
        moveCursor(1); 
        e.preventDefault(); 
    }
    else if (e.key === 'ArrowUp') { 
        moveCursor(-1); 
        e.preventDefault(); 
    }
    else if (e.key === 'Enter') { 
        // Click current item
        const lis = menuList.querySelectorAll('li');
        if (lis[cursor]) {
            lis[cursor].click();
        }
        e.preventDefault(); 
    }
    else if (e.key === 'Escape') { 
        if (currentMenu === 'main') {
            closeBennysMenu();
        } else {
            goBack();
        }
        e.preventDefault(); 
    }
});

// Controller input polling for menu navigation
let lastControllerInput = 0;
const CONTROLLER_INPUT_DELAY = 150; // ms debounce to prevent rapid inputs

setInterval(() => {
    if (!menuOpen) return;
    
    const now = Date.now();
    if (now - lastControllerInput < CONTROLLER_INPUT_DELAY) return;
    
    // Get gamepad
    const gamepads = navigator.getGamepads();
    if (!gamepads || !gamepads[0]) return;
    
    const gamepad = gamepads[0];
    
    // D-Pad up (button 12) or Left Stick up
    if (gamepad.buttons[12] && gamepad.buttons[12].pressed) {
        moveCursor(-1);
        lastControllerInput = now;
    }
    // D-Pad down (button 13) or Left Stick down
    else if (gamepad.buttons[13] && gamepad.buttons[13].pressed) {
        moveCursor(1);
        lastControllerInput = now;
    }
    // D-Pad left (button 14)
    else if (gamepad.buttons[14] && gamepad.buttons[14].pressed) {
        if (currentMenu === 'main') {
            closeBennysMenu();
        } else {
            goBack();
        }
        lastControllerInput = now;
    }
    // D-Pad right (button 15) - unused but mapped
    else if (gamepad.buttons[15] && gamepad.buttons[15].pressed) {
        // Right D-Pad reserved for future use
        lastControllerInput = now;
    }
    // A Button (button 0) - Select
    else if (gamepad.buttons[0] && gamepad.buttons[0].pressed) {
        const lis = menuList.querySelectorAll('li');
        if (lis[cursor]) {
            lis[cursor].click();
        }
        lastControllerInput = now;
    }
    // B Button (button 1) - Back
    else if (gamepad.buttons[1] && gamepad.buttons[1].pressed) {
        if (currentMenu === 'main') {
            closeBennysMenu();
        } else {
            goBack();
        }
        lastControllerInput = now;
    }
    // Left Stick Y axis for up/down navigation
    else if (Math.abs(gamepad.axes[1]) > 0.5) {
        if (gamepad.axes[1] < -0.5) {
            moveCursor(-1);
            lastControllerInput = now;
        } else if (gamepad.axes[1] > 0.5) {
            moveCursor(1);
            lastControllerInput = now;
        }
    }
}, 50); // Poll at 50ms for responsive input
