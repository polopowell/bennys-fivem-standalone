/**
 * Bennys Vehicle Customization System - NUI Script
 * Refactored for maintainability and simplicity
 *
 * Key Improvements:
 * - Simplified menu state management
 * - Extracted utility functions
 * - Unified menu navigation logic
 * - Reduced duplication in menu building
 * - Cleaner event handling
 */

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

const MenuState = {
    isOpen: false,
    currentMenu: 'main',
    cursor: 0,
    menuStack: [],
    cursorStack: {},
    mainMenu: [],
    modCache: {}
};

// ============================================================================
// DOM REFERENCES
// ============================================================================

const DOM = {
    menuContainer: document.getElementById('bennys-menu'),
    menuList: document.getElementById('menu-list'),
    menuTitle: document.getElementById('menu-title'),
    menuSub: document.getElementById('menu-sub'),
    menuStatus: document.getElementById('menu-status')
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Parse menu key that may include parameters (e.g., 'wheels::4' or 'paint::primary::gloss')
 * @param {string} key - Menu key to parse
 * @returns {object} Parsed components
 */
function parseMenuKey(key) {
    if (!key || key.indexOf('::') === -1) {
        return { base: key, param1: null, param2: null };
    }

    const parts = key.split('::');
    return {
        base: parts[0] || key,
        param1: parts[1] || null,
        param2: parts[2] || null
    };
}

/**
 * Build cache key for mod data
 * @param {string} modType
 * @param {string|number} wheelType
 * @param {string} finishType
 * @returns {string}
 */
function buildCacheKey(modType, wheelType = null, finishType = null) {
    let key = modType;
    if (wheelType !== null && wheelType !== undefined) {
        key += `::${wheelType}`;
    }
    if (finishType !== null && finishType !== undefined) {
        key += `::${finishType}`;
    }
    return key;
}

/**
 * Show status message
 * @param {string} text
 */
function showStatus(text) {
    if (!DOM.menuStatus) return;
    DOM.menuStatus.textContent = text;
    DOM.menuStatus.classList.remove('hidden');
}

/**
 * Hide status message
 */
function hideStatus() {
    if (!DOM.menuStatus) return;
    DOM.menuStatus.classList.add('hidden');
}

/**
 * Clear all applied badges from menu items
 */
function clearAppliedBadges() {
    const badges = DOM.menuList.querySelectorAll('.applied-badge');
    badges.forEach(badge => badge.remove());
}

/**
 * Add applied badge to menu item
 * @param {HTMLElement} listItem
 * @param {string} text
 */
function addAppliedBadge(listItem, text) {
    try {
        clearAppliedBadges();
        const badge = document.createElement('span');
        badge.className = 'applied-badge';
        badge.textContent = text;
        listItem.appendChild(badge);
    } catch (e) {
        console.error('[bennys] Failed to add badge:', e);
    }
}

/**
 * Flash visual feedback on item
 * @param {HTMLElement} listItem
 */
function flashItem(listItem) {
    listItem.style.backgroundColor = '#00ff00';
    listItem.style.color = '#000000';
    setTimeout(() => {
        listItem.style.backgroundColor = '';
        listItem.style.color = '';
    }, 300);
}

// ============================================================================
// API COMMUNICATION
// ============================================================================

/**
 * Fetch data from NUI
 * @param {string} endpoint
 * @param {object} data
 * @returns {Promise}
 */
async function fetchNUI(endpoint, data = {}) {
    try {
        const response = await fetch(`https://bennys/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return await response.json();
    } catch (error) {
        console.error(`[bennys] Fetch error (${endpoint}):`, error);
        return null;
    }
}

/**
 * Load main menu categories from server
 * @returns {Promise<Array>}
 */
async function loadMainMenu() {
    const data = await fetchNUI('getVehicleData');
    return data?.categories || [];
}

/**
 * Load mods for a specific type
 * @param {string} modType
 * @param {string|number} wheelType
 * @param {string} finishType
 * @returns {Promise<Array>}
 */
async function loadModsForType(modType, wheelType = null, finishType = null) {
    const cacheKey = buildCacheKey(modType, wheelType, finishType);

    // Return cached if available
    if (MenuState.modCache[cacheKey]) {
        return MenuState.modCache[cacheKey];
    }

    // Build request body
    const requestBody = { modType };
    if (wheelType !== null && wheelType !== undefined) {
        requestBody.wheelType = wheelType;
    }
    if (finishType !== null && finishType !== undefined) {
        requestBody.finishType = finishType;
    }

    // Fetch from server
    const data = await fetchNUI('getModsForType', requestBody);
    const mods = data?.mods || [];

    // Attach debug info if provided
    if (data?.debug) {
        mods.__debug = data.debug;
    }

    // Cache and return
    MenuState.modCache[cacheKey] = mods;
    return mods;
}

/**
 * Apply modification to vehicle
 * @param {string} modType
 * @param {number|object} modIndex
 * @param {number} wheelType
 * @param {string} finishType
 */
function applyMod(modType, modIndex, wheelType = null, finishType = null) {
    const body = { modType, modIndex };

    if (wheelType !== null && wheelType !== undefined) {
        body.wheelType = wheelType;
    }
    if (finishType !== null && finishType !== undefined) {
        body.finishType = finishType;
    }

    fetchNUI('applyMod', body).catch(err => {
        console.error('[bennys] applyMod error:', err);
    });

    showStatus('✓ Applied!');
}

/**
 * Close menu
 */
function closeMenu(skipServerNotify = false) {
    MenuState.isOpen = false;
    DOM.menuContainer.classList.add('hidden');
    hideStatus();
    if (!skipServerNotify) {
        fetchNUI('closeMenu').catch(() => {});
    }
}

// ============================================================================
// MENU BUILDING
// ============================================================================

/**
 * Get menu title and subtitle
 * @param {string} menuKey
 * @returns {object} {title, subtitle}
 */
function getMenuLabels(menuKey) {
    if (menuKey === 'main') {
        return {
            title: 'Customize your vehicle',
            subtitle: 'Choose a category'
        };
    }

    const parsed = parseMenuKey(menuKey);
    const categoryData = MenuState.mainMenu.find(m => m.id === parsed.base);
    const categoryName = categoryData?.name || 'Mods';

    return {
        title: categoryName,
        subtitle: 'Select a modification'
    };
}

/**
 * Build menu item object
 * @param {object} item - Raw item data
 * @param {string} currentMenu - Current menu key
 * @returns {object} Processed menu item
 */
function buildMenuItem(item, currentMenu) {
    // Main menu is the only true "category" view
    if (currentMenu === 'main') {
        return item;
    }

    const parsed = parseMenuKey(currentMenu);
    const baseType = parsed.base;
    const currentWheelType = parsed.param1;
    const currentFinishType = parsed.param2;

    // Treat every submenu entry as a mod item, even if the server did not tag it
    const resolvedModType = item.modType ?? baseType;
    const resolvedWheelType = (currentWheelType !== null && currentWheelType !== undefined)
        ? currentWheelType
        : (item.wheelType !== undefined ? item.wheelType : null);
    const resolvedFinishType = (currentFinishType !== null && currentFinishType !== undefined)
        ? currentFinishType
        : (item.finishType !== undefined ? item.finishType : null);

    return {
        id: item.id || `mod_${item.index}`,
        name: item.name,
        modType: resolvedModType,
        modIndex: item.index,
        wheelType: resolvedWheelType,
        finishType: resolvedFinishType,
        isPaintChannel: item.isPaintChannel || false,
        isPaintFinish: item.isPaintFinish || false,
        isWheelType: item.isWheelType || false,
        isInfo: item.isInfo || false,
        active: item.active || false
    };
}

/**
 * Create DOM element for menu item
 * @param {object} item - Menu item data
 * @param {number} index - Item index
 * @returns {HTMLLIElement}
 */
function createMenuItemElement(item, index) {
    const li = document.createElement('li');
    li.textContent = item.name;
    li.dataset.id = item.id;
    li.dataset.index = index;

    // Show persistent active badge if item is currently applied
    if (item.active) {
        addAppliedBadge(li, `${item.name} applied`);
    }

    // Attach click handler based on item type
    if (item.modType) {
        attachModItemHandler(li, item, index);
    } else {
        attachCategoryItemHandler(li, item, index);
    }

    return li;
}

/**
 * Attach click handler for mod item
 * @param {HTMLLIElement} li
 * @param {object} item
 * @param {number} index
 */
function attachModItemHandler(li, item, index) {
    if (item.isInfo) {
        // Info items are not clickable
        li.classList.add('info');
        return;
    }

    if (item.isPaintChannel) {
        // Navigate to paint finish selection
        li.onclick = async () => {
            saveCursorPosition();
            MenuState.menuStack.push(MenuState.currentMenu);
            MenuState.currentMenu = `${item.modType}::${item.wheelType}`;
            await loadModsForType(item.modType, item.wheelType);
            buildMenu();
        };
    } else if (item.isPaintFinish) {
        // Navigate to paint color selection
        li.onclick = async () => {
            saveCursorPosition();
            MenuState.menuStack.push(MenuState.currentMenu);
            MenuState.currentMenu = `${item.modType}::${item.wheelType}::${item.finishType}`;
            await loadModsForType(item.modType, item.wheelType, item.finishType);
            buildMenu();
        };
    } else if (item.isWheelType) {
        // Navigate to wheel variant selection
        li.onclick = async () => {
            saveCursorPosition();
            MenuState.menuStack.push(MenuState.currentMenu);
            MenuState.currentMenu = `${item.modType}::${item.wheelType}`;
            const mods = await loadModsForType(item.modType, item.wheelType);

            // Check for empty wheel variants (debug info)
            if (mods?.__debug?.probeCount <= 0) {
                const dbg = mods.__debug;
                mods.unshift({
                    index: -2,
                    name: `No variants (Type ${dbg.requestedType}, probe ${dbg.probeCount})`,
                    isInfo: true
                });
                MenuState.modCache[`${item.modType}::${item.wheelType}`] = mods;
            }

            buildMenu();
        };
    } else {
        // Standard mod application
        li.onclick = () => {
            MenuState.cursor = index;
            updateSelection();
            applyMod(item.modType, item.modIndex, item.wheelType, item.finishType);
            addAppliedBadge(li, `${item.name} applied`);
            flashItem(li);
        };
    }
}

/**
 * Attach click handler for category item
 * @param {HTMLLIElement} li
 * @param {object} item
 * @param {number} index
 */
function attachCategoryItemHandler(li, item, index) {
    li.onclick = () => {
        saveCursorPosition();
        enterCategory(item.id);
    };
}

/**
 * Build and render menu
 */
async function buildMenu() {
    DOM.menuList.innerHTML = '';

    // Restore saved cursor position or reset to 0
    if (MenuState.currentMenu in MenuState.cursorStack) {
        MenuState.cursor = MenuState.cursorStack[MenuState.currentMenu] || 0;
    } else {
        MenuState.cursor = 0;
    }

    // Get menu items
    let items = [];
    if (MenuState.currentMenu === 'main') {
        items = MenuState.mainMenu;
    } else {
        const cacheKey = MenuState.currentMenu;
        const mods = MenuState.modCache[cacheKey] || [];
        items = mods.map(mod => buildMenuItem(mod, MenuState.currentMenu));
    }

    // Update title and subtitle
    const labels = getMenuLabels(MenuState.currentMenu);
    DOM.menuTitle.textContent = labels.title;
    DOM.menuSub.textContent = labels.subtitle;

    // Create list items
    items.forEach((item, index) => {
        const li = createMenuItemElement(item, index);
        DOM.menuList.appendChild(li);
    });

    updateSelection();
}

/**
 * Enter a category submenu
 * @param {string} modType
 */
async function enterCategory(modType) {
    MenuState.menuStack.push(MenuState.currentMenu);
    MenuState.currentMenu = modType;
    await loadModsForType(modType);
    buildMenu();
}

/**
 * Go back to previous menu
 */
function goBack() {
    if (MenuState.menuStack.length > 0) {
        saveCursorPosition();
        MenuState.currentMenu = MenuState.menuStack.pop();
        buildMenu();
    } else {
        closeMenu();
    }
}

/**
 * Save current cursor position for current menu
 */
function saveCursorPosition() {
    MenuState.cursorStack[MenuState.currentMenu] = MenuState.cursor;
}

// ============================================================================
// CURSOR AND SELECTION
// ============================================================================

/**
 * Update visual selection highlighting
 */
function updateSelection() {
    const items = DOM.menuList.querySelectorAll('li');
    items.forEach(li => li.classList.remove('selected'));

    const currentItem = items[MenuState.cursor];
    if (currentItem) {
        currentItem.classList.add('selected');
        currentItem.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
}

/**
 * Move cursor by delta
 * @param {number} delta - Positive or negative offset
 */
function moveCursor(delta) {
    const items = DOM.menuList.querySelectorAll('li');
    MenuState.cursor += delta;

    // Clamp cursor
    MenuState.cursor = Math.max(0, Math.min(MenuState.cursor, items.length - 1));

    updateSelection();
}

/**
 * Select current item (trigger click)
 */
function selectCurrentItem() {
    const items = DOM.menuList.querySelectorAll('li');
    const currentItem = items[MenuState.cursor];
    if (currentItem) {
        currentItem.click();
    }
}

// ============================================================================
// MENU CONTROL
// ============================================================================

/**
 * Show Bennys menu
 */
async function showMenu() {
    MenuState.isOpen = true;
    MenuState.mainMenu = await loadMainMenu();
    MenuState.currentMenu = 'main';
    MenuState.menuStack = [];
    MenuState.cursorStack = {};
    DOM.menuContainer.classList.remove('hidden');
    buildMenu();
}

// ============================================================================
// EVENT LISTENERS
// ============================================================================

/**
 * Handle NUI messages
 */
window.addEventListener('message', (event) => {
    const data = event.data;

    if (data.type === 'toggle') {
        if (data.show) {
            showMenu();
        } else {
            closeMenu(true);
        }
    } else if (data.type === 'vehicleChanged') {
        // Clear cache when vehicle changes
        MenuState.modCache = {};
        if (MenuState.isOpen) {
            closeMenu(true);
        }
    }
});

/**
 * Keyboard navigation
 */
document.addEventListener('keydown', (e) => {
    if (!MenuState.isOpen) return;

    switch (e.key) {
        case 'ArrowDown':
            moveCursor(1);
            e.preventDefault();
            break;

        case 'ArrowUp':
            moveCursor(-1);
            e.preventDefault();
            break;

        case 'Enter':
            selectCurrentItem();
            e.preventDefault();
            break;

        case 'Escape':
            if (MenuState.currentMenu === 'main') {
                closeMenu();
            } else {
                goBack();
            }
            e.preventDefault();
            break;
    }
});

// ============================================================================
// CONTROLLER INPUT
// ============================================================================

let lastControllerInput = 0;
const CONTROLLER_INPUT_DELAY = 150; // ms debounce

/**
 * Controller input polling
 */
setInterval(() => {
    if (!MenuState.isOpen) return;

    const now = Date.now();
    if (now - lastControllerInput < CONTROLLER_INPUT_DELAY) return;

    const gamepads = navigator.getGamepads();
    if (!gamepads || !gamepads[0]) return;

    const gamepad = gamepads[0];

    // D-Pad Up (button 12)
    if (gamepad.buttons[12]?.pressed) {
        moveCursor(-1);
        lastControllerInput = now;
    }
    // D-Pad Down (button 13)
    else if (gamepad.buttons[13]?.pressed) {
        moveCursor(1);
        lastControllerInput = now;
    }
    // D-Pad Left or B button (button 1) - Back
    else if (gamepad.buttons[14]?.pressed || gamepad.buttons[1]?.pressed) {
        if (MenuState.currentMenu === 'main') {
            closeMenu();
        } else {
            goBack();
        }
        lastControllerInput = now;
    }
    // A button (button 0) - Select
    else if (gamepad.buttons[0]?.pressed) {
        selectCurrentItem();
        lastControllerInput = now;
    }
    // Left Stick Y axis
    else if (Math.abs(gamepad.axes[1]) > 0.5) {
        if (gamepad.axes[1] < -0.5) {
            moveCursor(-1);
        } else if (gamepad.axes[1] > 0.5) {
            moveCursor(1);
        }
        lastControllerInput = now;
    }
}, 50); // Poll every 50ms

console.log('[Bennys] NUI script loaded (refactored)');
