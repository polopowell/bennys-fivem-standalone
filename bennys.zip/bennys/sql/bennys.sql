-- SQL schema for Bennys resource
-- Run this on your MariaDB server (e.g., using mysql client or a DB manager)

CREATE TABLE IF NOT EXISTS `bennys_vehicle_mods` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(255) NOT NULL,
  `plate` VARCHAR(32) DEFAULT NULL,
  `vehicle_model` VARCHAR(64) DEFAULT NULL,
  `mod_type` VARCHAR(64) NOT NULL,
  `mod_index` VARCHAR(64) DEFAULT NULL,
  `wheel_type` VARCHAR(16) DEFAULT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_mod` (`identifier`, `vehicle_model`, `mod_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for storing full vehicle builds per player (JSON)
CREATE TABLE IF NOT EXISTS `bennys_vehicle_builds` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(255) NOT NULL,
  `plate` VARCHAR(32) DEFAULT NULL,
  `vehicle_model` VARCHAR(64) DEFAULT NULL,
  `build_json` LONGTEXT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_model` (`identifier`, `vehicle_model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
