local menuOpen = false
local currentVehicle = nil

-- Vehicle mod data with actual mod counts per vehicle type
-- (modTypeMapping removed - slots are defined here instead)
local vehicleModData = {
    spoiler = { name = "Spoiler", slot = 0, max = 0 },
    frontbumper = { name = "Front Bumper", slot = 1, max = 0 },
    rearbumper = { name = "Rear Bumper", slot = 2, max = 0 },
    sideskirt = { name = "Side Skirt", slot = 3, max = 0 },
    exhaust = { name = "Exhaust", slot = 4, max = 0 },
    frame = { name = "Frame", slot = 5, max = 0 },
    grille = { name = "Grille", slot = 6, max = 0 },
    hood = { name = "Hood", slot = 7, max = 0 },
    fender = { name = "Fender", slot = 8, max = 0 },
    rightfender = { name = "Right Fender", slot = 9, max = 0 },
    roof = { name = "Roof", slot = 10, max = 0 },
    engine = { name = "Engine", slot = 11, max = 0 },
    brakes = { name = "Brakes", slot = 12, max = 0 },
    horn = { name = "Horn", slot = 14, max = 0 },
    suspension = { name = "Suspension", slot = 15, max = 0 },
    turbo = { name = "Turbo", slot = 18, max = 2 },
    paint = { name = "Paint", slot = 20, max = 0 },
    wheels = { name = "Wheels", slot = 23, max = 0 },
    livery = { name = "Livery", slot = -2, max = -1 },
    xenon = { name = "Xenon Headlights", slot = 22, max = 0 },
    neon = { name = "Neon Underglow", slot = -1, max = 0 },
    plate = { name = "License Plate", slot = 25, max = 0 },
    windowtint = { name = "Window Tint", slot = 99, max = 5 },
}

-- Xenon menu -> engine index mapping. Adjust these if your build maps xenon indices differently.
-- (pearlescentPalette removed - using native GTA 5 color indices for all paint channels)
-- If the xenon 'Blue' label appears too dark, set it to the brighter index observed via /bennys_xenondbg.
local xenonIndexMap = {
    ['Off'] = -1,
    ['Default (Stock)'] = 255,
    ['White'] = 0,
    ['Blue'] = 1,            -- dark/medium blue
    ['Electric Blue'] = 2,   -- bright cyan blue
    ['Mint Green'] = 3,
    ['Lime Green'] = 4,
    ['Yellow'] = 5,
    ['Golden Shower'] = 6,
    ['Orange'] = 7,
    ['Red'] = 8,
    ['Pony Pink'] = 9,
    ['Hot Pink'] = 10,
    ['Purple'] = 11,
    ['Blacklight'] = 12,
}

-- Xenon color palette - dynamic list for easy customization
local xenonPalette = {
    { index = -1, name = "Off" },
    { index = 255, name = "Default (Stock)" },
    { index = 0, name = "White" },
    { index = 1, name = "Blue" },
    { index = 2, name = "Electric Blue" },
    { index = 3, name = "Mint Green" },
    { index = 4, name = "Lime Green" },
    { index = 5, name = "Yellow" },
    { index = 6, name = "Golden Shower" },
    { index = 7, name = "Orange" },
    { index = 8, name = "Red" },
    { index = 9, name = "Pony Pink" },
    { index = 10, name = "Hot Pink" },
    { index = 11, name = "Purple" },
    { index = 12, name = "Blacklight" }
}

-- Neon color palette - RGB values for dynamic menu generation
-- Aligned with xenon indices so colors match across both systems
local neonPalette = {
    { index = -1, name = "Off", rgb = {255,255,255} },
    { index = 0, name = "White", rgb = {255,255,255} },
    { index = 1, name = "Blue", rgb = {18,70,140} },
    { index = 2, name = "Electric Blue", rgb = {0,150,220} },
    { index = 3, name = "Mint Green", rgb = {130,240,200} },
    { index = 4, name = "Lime Green", rgb = {150,255,0} },
    { index = 5, name = "Yellow", rgb = {255,230,0} },
    { index = 6, name = "Golden Shower", rgb = {255,200,0} },
    { index = 7, name = "Orange", rgb = {255,140,0} },
    { index = 8, name = "Red", rgb = {255,0,0} },
    { index = 9, name = "Pony Pink", rgb = {255,105,180} },
    { index = 10, name = "Hot Pink", rgb = {255,20,147} },
    { index = 11, name = "Purple", rgb = {128,0,200} },
    { index = 12, name = "Blacklight", rgb = {100,0,230} },
    { index = 255, name = "Stock", rgb = {255,255,255} }
}

-- Plate style palette - indices are engine/build dependent; edit names as needed
local platePalette = {
    { index = -1, name = "Stock" },
    { index = 0, name = "Plate Style 0" },
    { index = 1, name = "Plate Style 1" },
    { index = 2, name = "Plate Style 2" },
    { index = 3, name = "Plate Style 3" },
    { index = 4, name = "Plate Style 4" },
    { index = 5, name = "Plate Style 5" },
    { index = 6, name = "Plate Style 6" },
    { index = 7, name = "Plate Style 7" }
}

-- Command to open Bennys menu
-- (GetAvailableModsForSlot removed - using GetNumVehicleMods directly)
RegisterCommand('bennys', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Bennys", "You need to be in a vehicle!"}
        })
        return
    end
    
    currentVehicle = vehicle
    
    -- Update mod counts based on current vehicle
    for modType, modData in pairs(vehicleModData) do
        -- Ensure mod kit is set so GetNumVehicleMods returns correct values
        SetVehicleModKit(vehicle, 0)
        -- GetNumVehicleMods returns number of mods for that slot (or 0)
        local modCount = 0
        pcall(function()
            modCount = GetNumVehicleMods(vehicle, modData.slot) or 0
        end)
        -- store max usable index (0..modCount-1). If no mods, max = -1
        vehicleModData[modType].max = (modCount > 0) and (modCount - 1) or -1
    end
    
    ToggleBennysMenu(true)
end, false)

-- Diagnostic command: list neon/xenon native availability and try safe calls
RegisterCommand('bennys_lightdbg', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline=true, args = {'Bennys Debug', 'You need to be in a vehicle!'} })
        return
    end

    local nativesToCheck = {
        'SetVehicleXenonLightColorIndex', 'SetVehicleHeadlightsColour', 'SetVehicleHeadlightsColourIndex',
        'SetVehicleNeonLightColor', 'SetVehicleNeonLightColour', 'SetVehicleNeonLightsColour', 'SetVehicleNeonLightsColor',
        'SetVehicleNeonColour', 'SetVehicleNeonColor'
    }

    local results = {}
    for _, name in ipairs(nativesToCheck) do
        local fn = _G[name]
        if fn ~= nil then
            -- Try a safe pcall invocation with conservative args to see if it errors
            local ok, err = pcall(function()
                -- call with minimal args where possible; wrap in pcall so it won't crash
                if name:find('Xenon') then
                    fn(vehicle, 0)
                else
                    -- try rgb call; if it errors we'll note that
                    fn(vehicle, 255, 255, 255)
                end
            end)
            table.insert(results, name .. ': present, callable=' .. tostring(ok))
        else
            table.insert(results, name .. ': missing')
        end
    end

    -- Try to read current xenon color if native exists
    local xenonColor = nil
    if _G['GetVehicleXenonLightColorIndex'] ~= nil then
        pcall(function()
            xenonColor = GetVehicleXenonLightColorIndex(vehicle)
        end)
    end

    TriggerEvent('chat:addMessage', {
        color = {0,255,200}, multiline = true,
        args = {'Bennys Debug', 'Neon/Xenon native check: ' .. table.concat(results, ' | ')}
    })
    if xenonColor ~= nil then
        TriggerEvent('chat:addMessage', { color = {0,255,200}, multiline=true, args = {'Bennys Debug', 'GetVehicleXenonLightColorIndex -> ' .. tostring(xenonColor)} })
    end
end, false)

-- Xenon color probe: cycle through common xenon color indices so server admins/players can see which indices map to which visual colors
RegisterCommand('bennys_xenondbg', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline=true, args = {'Bennys Debug', 'You need to be in a vehicle!'} })
        return
    end

    -- Common indices used by many builds (0..12 plus 255 as 'stock/default')
    local indices = {0,1,2,3,4,5,6,7,8,9,10,11,12,255}
    local appliedAny = false
    local origEnabled = nil
    -- Remember original xenon enabled state so we restore later
    pcall(function() origEnabled = IsToggleModOn(vehicle, 22) end)

    -- Ensure xenon mod is enabled for visual change
    pcall(function() ToggleVehicleMod(vehicle, 22, true) end)
    Citizen.Wait(120)

    for _, idx in ipairs(indices) do
        local ok = false
        pcall(function()
            if SetVehicleXenonLightColorIndex ~= nil then
                SetVehicleXenonLightColorIndex(vehicle, idx)
                ok = true
            elseif SetVehicleHeadlightsColour ~= nil then
                SetVehicleHeadlightsColour(vehicle, idx)
                ok = true
            elseif SetVehicleHeadlightsColourIndex ~= nil then
                SetVehicleHeadlightsColourIndex(vehicle, idx)
                ok = true
            end
        end)
        if ok then
            appliedAny = true
            TriggerEvent('chat:addMessage', { color = {0,200,200}, multiline=true, args = {'Bennys Debug', 'Xenon probe: set index ' .. tostring(idx) .. ' (observe headlights)'}})
            Citizen.Wait(800)
        else
            TriggerEvent('chat:addMessage', { color = {200,100,0}, multiline=true, args = {'Bennys Debug', 'Xenon probe: native to set index ' .. tostring(idx) .. ' not available on this build.'}})
            Citizen.Wait(200)
        end
    end

    -- restore original xenon enabled state (best effort)
    pcall(function() ToggleVehicleMod(vehicle, 22, origEnabled and true or false) end)
    TriggerEvent('chat:addMessage', { color = {0,200,0}, multiline=true, args = {'Bennys Debug', appliedAny and 'Xenon probe finished; report which index matched neon blue.' or 'Xenon probe could not set any indices on this build.'}})
end, false)

-- Quick setter: /bennys_setxenon <index>
-- Use this to test a specific xenon color index immediately (enables xenon briefly)
RegisterCommand('bennys_setxenon', function(source, args)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline=true, args = {'Bennys Debug', 'You need to be in a vehicle!'} })
        return
    end
    if not args or not args[1] then
        TriggerEvent('chat:addMessage', { color = {200,200,0}, multiline=true, args = {'Bennys Debug', 'Usage: /bennys_setxenon <index>'} })
        return
    end
    local idx = tonumber(args[1])
    if idx == nil then
        TriggerEvent('chat:addMessage', { color = {200,100,0}, multiline=true, args = {'Bennys Debug', 'Invalid index: ' .. tostring(args[1])} })
        return
    end

    -- Ensure xenon toggle is enabled so color is visible
    pcall(function() ToggleVehicleMod(vehicle, 22, true) end)
    Citizen.Wait(80)

    local applied = false
    pcall(function()
        if SetVehicleXenonLightColorIndex ~= nil then
            SetVehicleXenonLightColorIndex(vehicle, idx)
            applied = true
        elseif SetVehicleHeadlightsColour ~= nil then
            SetVehicleHeadlightsColour(vehicle, idx)
            applied = true
        elseif SetVehicleHeadlightsColourIndex ~= nil then
            SetVehicleHeadlightsColourIndex(vehicle, idx)
            applied = true
        end
    end)

    if applied then
        TriggerEvent('chat:addMessage', { color = {0,200,200}, multiline=true, args = {'Bennys Debug', 'Tried setting xenon index ' .. tostring(idx) .. '. Observe headlights.'} })
    else
        TriggerEvent('chat:addMessage', { color = {200,100,0}, multiline=true, args = {'Bennys Debug', 'No xenon color native available on this build to set index ' .. tostring(idx)} })
    end
end, false)

-- Command to set plain plate text on the current vehicle (client-side helper)
RegisterCommand('bennys_setplate', function(source, args, raw)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline=true, args = {'Bennys Debug', 'You need to be in a vehicle!'} })
        return
    end
    local text = table.concat(args, ' ')
    if not text or text == '' then
        TriggerEvent('chat:addMessage', { color = {255,160,0}, multiline=true, args = {'Bennys', 'Usage: /bennys_setplate <TEXT>'} })
        return
    end
    pcall(function()
        if SetVehicleNumberPlateText ~= nil then
            SetVehicleNumberPlateText(vehicle, text)
            TriggerEvent('chat:addMessage', { color = {0,200,0}, multiline=true, args = {'Bennys', 'Plate text updated to: ' .. tostring(text)} })
        else
            TriggerEvent('chat:addMessage', { color = {255,100,0}, multiline=true, args = {'Bennys', 'SetVehicleNumberPlateText native not available on this build.'} })
        end
    end)
end, false)

-- Toggle the menu
function ToggleBennysMenu(state)
    menuOpen = state
    SendNUIMessage({
        type = "toggle",
        show = state,
        vehicleModel = GetDisplayNameFromVehicleModel(GetEntityModel(currentVehicle))
    })
    -- Allow mouse for menu but keep keyboard/camera working
    SetNuiFocus(state, false)
end

-- Get current vehicle modification data
RegisterNUICallback('getModsForType', function(data, cb)
    if not currentVehicle or currentVehicle == 0 then
        cb({ mods = {} })
        return
    end
    
    local modType = data.modType
    local requestedWheelType = data.wheelType
    if not vehicleModData[modType] then
        cb({ mods = {} })
        return
    end
    
    local modData = vehicleModData[modType]
    local mods = {}
    -- Read current vehicle state to mark which mod/option is currently applied
    SetVehicleModKit(currentVehicle, 0)
    local currentSlotValue = nil
    pcall(function() if modData and modData.slot then currentSlotValue = GetVehicleMod(currentVehicle, modData.slot) end end)
    local hasTurbo = false; pcall(function() if modData and modData.slot then hasTurbo = IsToggleModOn(currentVehicle, modData.slot) end end)
    local currentTint = nil; pcall(function() if GetVehicleWindowTint ~= nil then currentTint = GetVehicleWindowTint(currentVehicle) end end)
    local currentXenon = nil; pcall(function()
        if GetVehicleXenonLightColorIndex ~= nil then currentXenon = GetVehicleXenonLightColorIndex(currentVehicle)
        elseif GetVehicleHeadlightsColour ~= nil then currentXenon = GetVehicleHeadlightsColour(currentVehicle)
        elseif GetVehicleHeadlightsColourIndex ~= nil then currentXenon = GetVehicleHeadlightsColourIndex(currentVehicle)
        end
    end)
    local currentNeonIndex = nil; pcall(function() if GetVehicleNeonLightColorIndex ~= nil then currentNeonIndex = GetVehicleNeonLightColorIndex(currentVehicle) end end)
    local currentPrimary = nil; local currentSecondary = nil
    pcall(function()
        if GetVehicleCustomPrimaryColour ~= nil then
            local r,g,b = GetVehicleCustomPrimaryColour(currentVehicle)
            if r ~= nil and g ~= nil and b ~= nil then currentPrimary = { r,g,b } end
        end
        if GetVehicleCustomSecondaryColour ~= nil then
            local r2,g2,b2 = GetVehicleCustomSecondaryColour(currentVehicle)
            if r2 ~= nil and g2 ~= nil and b2 ~= nil then currentSecondary = { r2,g2,b2 } end
        end
    end)
    -- Fallback to indexed colours if custom RGB not present
    pcall(function()
        if (currentPrimary == nil or currentSecondary == nil) and GetVehicleColours ~= nil then
            local p,s = GetVehicleColours(currentVehicle)
            if p ~= nil and currentPrimary == nil then currentPrimary = tonumber(p) end
            if s ~= nil and currentSecondary == nil then currentSecondary = tonumber(s) end
        end
    end)
    
    -- Special handling for certain mod types
    if modType == "turbo" then
        SetVehicleModKit(currentVehicle, 0)
        -- Toggle style mod: use IsToggleModOn to check and ToggleVehicleMod to set
        local hasTurbo = false
        pcall(function()
            hasTurbo = IsToggleModOn(currentVehicle, modData.slot)
        end)
        mods = {
            { index = -1, name = "Remove Turbo", active = hasTurbo },
            { index = 1, name = "Add Turbo", active = not hasTurbo }
        }
    
    elseif modType == "windowtint" then
        mods = {
            { index = -1, name = "None", active = (currentTint == nil or currentTint == -1) },
            { index = 0, name = "Pure Black", active = (currentTint == 0) },
            { index = 1, name = "Dark Smoke", active = (currentTint == 1) },
            { index = 2, name = "Light Smoke", active = (currentTint == 2) },
            { index = 3, name = "Limo", active = (currentTint == 3) },
            { index = 4, name = "Green", active = (currentTint == 4) },
            { index = 5, name = "Dark Green", active = (currentTint == 5) }
        }
    
    elseif modType == "xenon" then
        -- Xenon headlights with color options - dynamically built from xenonPalette
        mods = {}
        for _, entry in ipairs(xenonPalette) do
            local active = false
            if entry.index == -1 then
                -- consider xenon off when toggle is false
                local enabled = false; pcall(function() enabled = IsToggleModOn(currentVehicle, 22) end)
                active = not enabled
            else
                if currentXenon ~= nil and tonumber(currentXenon) == tonumber(entry.index) then
                    active = true
                end
            end
            table.insert(mods, { index = entry.index, name = entry.name, active = active })
        end
    
    elseif modType == "neon" then
        -- Neon underglow with color options - dynamically built from neonPalette
        mods = {}
        for _, entry in ipairs(neonPalette) do
            local active = false
            if entry.index == -1 then
                -- consider neon off when not enabled
                local enabled = false; pcall(function() enabled = IsToggleModOn(currentVehicle, -1) end)
                active = not enabled
            end
            table.insert(mods, { index = entry.index, name = entry.name, rgb = entry.rgb, active = active })
        end

    elseif modType == "plate" then
        -- License plate style selector
        mods = {}
        -- Try to read current plate style index if native exists
        local currentPlateIndex = nil
        pcall(function()
            if GetVehicleNumberPlateTextIndex ~= nil then
                currentPlateIndex = GetVehicleNumberPlateTextIndex(currentVehicle)
            end
        end)

        for _, entry in ipairs(platePalette) do
            local active = false
            if currentPlateIndex ~= nil and tonumber(currentPlateIndex) == tonumber(entry.index) then
                active = true
            end
            table.insert(mods, { index = entry.index, name = entry.name, active = active })
        end

    elseif modType == "livery" then
        -- Vehicle liveries (some vehicles expose a number of liveries)
        mods = {}
        -- Stock option
        table.insert(mods, { index = -1, name = "Stock" })
        -- Ensure modkit set and probe livery count
        SetVehicleModKit(currentVehicle, 0)
        local lcount = 0
        pcall(function()
            if GetVehicleLiveryCount ~= nil then
                lcount = GetVehicleLiveryCount(currentVehicle) or 0
            end
        end)
        if lcount > 0 then
            for i = 0, lcount - 1 do
                local label = nil
                pcall(function()
                    -- Try a few possible native names for a livery name getter
                    if GetVehicleLiveryName ~= nil then
                        label = GetVehicleLiveryName(currentVehicle, i)
                    elseif GetLiveryName ~= nil then
                        label = GetLiveryName(currentVehicle, i)
                    end
                end)
                if not label or label == '' then
                    label = "Livery #" .. (i + 1)
                end
                table.insert(mods, { index = i, name = label })
            end
        end

    elseif modType == "paint" then
        -- If no specific paint channel requested, present the four paint options as submenu entries
        if requestedWheelType == nil then
            mods = {}
            table.insert(mods, { index = 200, name = "Primary", wheelType = 'primary', isPaintChannel = true })
            table.insert(mods, { index = 201, name = "Secondary", wheelType = 'secondary', isPaintChannel = true })
            table.insert(mods, { index = 202, name = "Pearlescent", wheelType = 'pearlescent', isPaintChannel = true })
            table.insert(mods, { index = 203, name = "Wheel Color", wheelType = 'wheel', isPaintChannel = true })
            cb({ mods = mods })
            return
        end

        -- Check if user is requesting a finish type (gloss/matte) instead of colors
        local finishType = data.finishType
        if finishType == nil then
            -- Show gloss/matte options for the selected paint channel
            mods = {
                { index = 1000, name = "Gloss", finishType = 'gloss', isPaintFinish = true },
                { index = 1001, name = "Matte", finishType = 'matte', isPaintFinish = true }
            }
            cb({ mods = mods })
            return
        end

        -- Native GTA 5 color palette (organized by category)
        -- Gloss colors - metallic and standard finishes
        local glossColors = {
            { index = -1, name = "Stock" },
            -- Black Colors  
            { index = 0, name = "Black" },
            { index = 1, name = "Graphite" },
            { index = 2, name = "Steel" },
            { index = 3, name = "Silver" },
            { index = 4, name = "Pale Silver" },
            { index = 5, name = "Rolled Steel" },
            { index = 6, name = "Brushed Steel" },
            { index = 7, name = "Dark Steel" },
            { index = 8, name = "Oil" },
            { index = 9, name = "Carbon" },
            { index = 10, name = "Night Black" },
            { index = 11, name = "Dark Black" },
            { index = 12, name = "Deep Black" },
            { index = 13, name = "Glossy Black" },
            -- Red Colors
            { index = 27, name = "Red" },
            { index = 28, name = "Torino Red" },
            { index = 29, name = "Formula Red" },
            { index = 30, name = "Lava Red" },
            { index = 31, name = "Blaze Red" },
            { index = 32, name = "Grace Red" },
            { index = 33, name = "Garnet Red" },
            { index = 34, name = "Sunset Red" },
            { index = 35, name = "Cabernet Red" },
            { index = 36, name = "Wine Red" },
            { index = 37, name = "Candy Red" },
            -- Orange Colors
            { index = 38, name = "Sunrise Orange" },
            { index = 39, name = "Orangutang Orange" },
            -- Yellow Colors
            { index = 40, name = "Bright Yellow" },
            { index = 41, name = "Racing Yellow" },
            -- Green Colors
            { index = 49, name = "Dark Green" },
            { index = 50, name = "Racing Green" },
            { index = 51, name = "Sea Green" },
            { index = 52, name = "Olive Green" },
            { index = 53, name = "Green" },
            { index = 54, name = "Gasoline Blue Green" },
            { index = 55, name = "Sea Wash Green" },
            { index = 56, name = "Cyber Green" },
            { index = 57, name = "Electric Green" },
            { index = 58, name = "Lime Green" },
            -- Blue Colors
            { index = 61, name = "Midnight Blue" },
            { index = 62, name = "Dark Blue" },
            { index = 63, name = "Saxony Blue" },
            { index = 64, name = "Blue" },
            { index = 65, name = "Mariner Blue" },
            { index = 66, name = "Harbor Blue" },
            { index = 67, name = "Diamond Blue" },
            { index = 68, name = "Surf Blue" },
            { index = 69, name = "Nautical Blue" },
            { index = 70, name = "Bright Blue" },
            { index = 71, name = "Purple Blue" },
            { index = 72, name = "Spinnaker Blue" },
            { index = 73, name = "Ultramarine Blue" },
            { index = 74, name = "Tropical Blue" },
            -- Purple Colors
            { index = 75, name = "Mauve" },
            { index = 76, name = "Dark Purple" },
            { index = 77, name = "Purple" },
            { index = 78, name = "Spinnaker Purple" },
            { index = 79, name = "Deep Purple" },
            { index = 80, name = "Neon Purple" },
            -- Brown/Beige Colors
            { index = 88, name = "Taxi Yellow" },
            { index = 89, name = "Race Yellow" },
            { index = 90, name = "Bronze" },
            { index = 91, name = "Yellow Bird" },
            { index = 92, name = "Lime Green" },
            { index = 93, name = "Champagne" },
            { index = 94, name = "Desert Tan" },
            { index = 95, name = "Pueblo Beige" },
            { index = 96, name = "Dark Ivory" },
            { index = 97, name = "Choco Brown" },
            { index = 98, name = "Golden Brown" },
            { index = 99, name = "Light Brown" },
            { index = 100, name = "Straw Beige" },
            { index = 101, name = "Moss Brown" },
            { index = 102, name = "Biston Brown" },
            { index = 103, name = "Beechwood" },
            { index = 104, name = "Dark Beechwood" },
            { index = 105, name = "Choco Orange" },
            { index = 106, name = "Beach Sand" },
            { index = 107, name = "Sun Bleached Sand" },
            { index = 108, name = "Cream" },
            -- White Colors
            { index = 111, name = "White" },
            { index = 112, name = "Frost White" },
            -- Chrome & Metals
            { index = 120, name = "Chrome" },
            { index = 121, name = "Off White" },
            { index = 122, name = "Ultra White" },
            { index = 125, name = "Hunter Green" },
            -- Worn Colors
            { index = 126, name = "Worn Dark Blue" },
            { index = 127, name = "Worn Blue" },
            { index = 128, name = "Worn Light Blue" },
            { index = 129, name = "Worn Graphite" },
            { index = 130, name = "Worn Silver" },
            { index = 131, name = "Worn Pale Silver" },
            { index = 132, name = "Worn Rolled Steel" },
            { index = 133, name = "Worn Brushed Steel" },
            { index = 134, name = "Pure White" },
            { index = 135, name = "Hot Pink" },
            { index = 136, name = "Salmon Pink" },
            { index = 137, name = "Vermillion Pink" },
            { index = 138, name = "Orange" },
            { index = 139, name = "Green" },
            { index = 140, name = "Cobalt Blue" },
            { index = 141, name = "Dark Cobalt Blue" },
            { index = 145, name = "Metallic Purple" },
            { index = 146, name = "Matte Yellow" },
            { index = 147, name = "Carbon Black" },
            { index = 148, name = "Matte Purple" },
            { index = 149, name = "Matte Green" },
            { index = 150, name = "Matte Brown" },
            { index = 151, name = "Matte Forest Green" },
            { index = 152, name = "Matte Black" },
            { index = 156, name = "Brushed Steel" },
            { index = 157, name = "Brushed Aluminum" },
            { index = 158, name = "Pure Gold" },
            { index = 159, name = "Brushed Gold" }
        }

        -- Matte colors - matte/flat finishes
        local matteColors = {
            { index = -1, name = "Stock" },
            { index = 12, name = "Matte Black" },
            { index = 13, name = "Matte Dark Gray" },
            { index = 14, name = "Matte Gray" },
            { index = 15, name = "Matte Light Gray" },
            { index = 16, name = "Matte Asbestos" },
            { index = 17, name = "Matte Blueish Gray" },
            { index = 18, name = "Matte Dark Blue" },
            { index = 19, name = "Matte Midnight Blue" },
            { index = 20, name = "Matte Midnight Purple" },
            { index = 21, name = "Matte Dark Purple" },
            { index = 22, name = "Matte Red" },
            { index = 23, name = "Matte Dark Red" },
            { index = 24, name = "Matte Orange" },
            { index = 25, name = "Matte Yellow" },
            { index = 26, name = "Matte Lime Green" },
            { index = 27, name = "Matte Green" },
            { index = 28, name = "Matte Forest Green" },
            { index = 29, name = "Matte Olive Green" },
            { index = 30, name = "Matte Dark Green" },
            { index = 31, name = "Matte Sea Green" },
            { index = 32, name = "Matte Sage Green" },
            { index = 33, name = "Matte Brown" },
            { index = 34, name = "Matte Dark Brown" },
            { index = 35, name = "Matte Earth Brown" },
            { index = 36, name = "Matte Light Brown" },
            { index = 37, name = "Matte Dark Tan" },
            { index = 38, name = "Matte Tan" },
            { index = 39, name = "Matte Light Tan" },
            { index = 40, name = "Matte Sand" },
            { index = 41, name = "Matte Beige" },
            { index = 42, name = "Matte Cream" },
            { index = 43, name = "Matte White" },
            { index = 44, name = "Matte Frost White" },
            { index = 143, name = "Worn Matte Black" },
            { index = 144, name = "Worn Matte Gray" },
            { index = 145, name = "Worn Matte Light Gray" },
            { index = 146, name = "Worn Matte Asbestos" },
            { index = 147, name = "Worn Matte Blueish Gray" },
            { index = 148, name = "Worn Matte Dark Blue" },
            { index = 149, name = "Worn Matte Midnight Blue" },
            { index = 150, name = "Worn Matte Blue" },
            { index = 151, name = "Worn Matte Light Blue" }
        }

        -- Select color palette based on finish type
        local colorPalette = (finishType == 'gloss') and glossColors or matteColors
        mods = colorPalette
        
    
    else
        -- Standard mod slots - list all variants
        mods[1] = { index = -1, name = "Stock" }
        
        -- Special handling for wheels: show wheel types or variants based on wheelType param
        local debugInfo = nil
        if modType == 'wheels' then
            if requestedWheelType == nil then
                -- Show wheel type options (Sport, Offroad)
                table.insert(mods, { index = 100, name = "Sport Wheels", wheelType = 0, isWheelType = true })
                table.insert(mods, { index = 101, name = "Offroad Wheels", wheelType = 4, isWheelType = true })
                cb({ mods = mods })
                return
            else
                -- Try to set the vehicle's wheel type once (pcall to avoid crashes).
                local setOk = false
                pcall(function()
                    SetVehicleWheelType(currentVehicle, tonumber(requestedWheelType))
                    setOk = true
                end)
                if setOk then
                    Citizen.Wait(150)
                end
                -- We'll populate mods after this; attach initial debug info and update probeCount later
                debugInfo = { requestedType = requestedWheelType, setOk = setOk, probeCount = nil }
            end
        end
        
        -- ensure modkit set so mod counts are populated correctly
        SetVehicleModKit(currentVehicle, 0)
        local modCount = 0
        pcall(function()
            modCount = GetNumVehicleMods(currentVehicle, modData.slot) or 0
        end)
        if debugInfo then
            debugInfo.probeCount = modCount
        end
        if modCount > 0 then
            for i = 0, modCount - 1 do
                local label = nil
                pcall(function()
                    if GetModTextLabel ~= nil then
                        label = GetModTextLabel(currentVehicle, modData.slot, i)
                    end
                end)
                if not label or label == '' then
                    label = modData.name .. " #" .. (i + 1)
                end
                table.insert(mods, {
                    index = i,
                    name = label
                })
            end
        end
    end
    
    if debugInfo then
        -- If this is the paint palette, reorder entries: put Pure White, a Black, then blues at the top
        if modType == 'paint' then
            local desired = { 'Pure White', 'Matte Black', 'Blue', 'Metallic Bright Blue', 'Metallic Ultra Blue', 'Metallic Blue', 'Metallic Mariner Blue', 'Metallic Diamond Blue', 'Metallic Surf Blue', 'Metallic Nautical Blue', 'Matte Blue' }
            local used = {}
            local reordered = {}
            -- collect desired in order if they exist
            for _,want in ipairs(desired) do
                for i,entry in ipairs(mods) do
                    if not used[i] and entry.name == want then
                        table.insert(reordered, entry)
                        used[i] = true
                        break
                    end
                end
            end
            -- append remaining entries not used
            for i,entry in ipairs(mods) do
                if not used[i] then table.insert(reordered, entry) end
            end
            mods = reordered
        end
        -- If a specific paint channel was requested, map base paint entries to channel-specific entries
        if modType == 'paint' and requestedWheelType ~= nil then
            local finishType = data.finishType
            local expanded = {}
            if requestedWheelType == 'primary' or requestedWheelType == 'secondary' or requestedWheelType == 'pearlescent' or requestedWheelType == 'wheel' then
                for _,entry in ipairs(mods) do
                    local baseIndex = entry.index
                    local baseName = entry.name or tostring(baseIndex)
                    table.insert(expanded, { 
                        index = { subtype = requestedWheelType, value = baseIndex, finishType = finishType }, 
                        name = baseName 
                    })
                end
            end
            mods = expanded
        end
        cb({ mods = mods, debug = debugInfo })
    else
        if modType == 'paint' then
            local desired = { 'Pure White', 'Matte Black', 'Blue', 'Metallic Bright Blue', 'Metallic Ultra Blue', 'Metallic Blue', 'Metallic Mariner Blue', 'Metallic Diamond Blue', 'Metallic Surf Blue', 'Metallic Nautical Blue', 'Matte Blue' }
            local used = {}
            local reordered = {}
            for _,want in ipairs(desired) do
                for i,entry in ipairs(mods) do
                    if not used[i] and entry.name == want then
                        table.insert(reordered, entry)
                        used[i] = true
                        break
                    end
                end
            end
            for i,entry in ipairs(mods) do
                if not used[i] then table.insert(reordered, entry) end
            end
            mods = reordered
        end
        -- If a specific paint channel was requested, map base paint entries to that channel
        if modType == 'paint' and requestedWheelType ~= nil then
            local finishType = data.finishType
            local expanded = {}
            if requestedWheelType == 'primary' or requestedWheelType == 'secondary' or requestedWheelType == 'pearlescent' or requestedWheelType == 'wheel' then
                for _,entry in ipairs(mods) do
                    local baseIndex = entry.index
                    local baseName = entry.name or tostring(baseIndex)
                    table.insert(expanded, { 
                        index = { subtype = requestedWheelType, value = baseIndex, finishType = finishType }, 
                        name = baseName 
                    })
                end
            end
            mods = expanded
        end
        cb({ mods = mods })
    end
end)

-- Apply vehicle modification using FiveM natives
RegisterNUICallback('applyMod', function(data, cb)
    if not currentVehicle or currentVehicle == 0 then
        cb({ status = 'error', message = 'No vehicle' })
        return
    end
    
    local modType = data.modType
    local rawModIndex = data.modIndex
    local modIndex = nil
    -- For paint we expect RGB table or numeric index; preserve table as-is
    if modType == 'paint' then
        modIndex = rawModIndex
    else
        modIndex = tonumber(rawModIndex)
    end
    local wheelType = data.wheelType
    
    if not vehicleModData[modType] then
        cb({ status = 'error', message = 'Invalid mod type' })
        return
    end
    
    local modData = vehicleModData[modType]
    local modSlot = modData.slot

    -- Debug: log paint payloads to help diagnose missing wheel-color actions
    pcall(function()
        if modType == 'paint' then
            local ok, dumped = pcall(function() return json.encode(rawModIndex) end)
            if ok and dumped then
                print('[bennys applyMod] paint payload: ' .. tostring(dumped))
            else
                print('[bennys applyMod] paint payload: <unable to encode>')
            end
            -- If it's a wheel subtype, also post a short chat message so user sees immediate feedback
            if type(rawModIndex) == 'table' and rawModIndex.subtype == 'wheel' then
                TriggerEvent('chat:addMessage', { color = {0,200,200}, multiline = true, args = {'Bennys', 'Wheel apply requested (debug)'} })
            end
        end
    end)
    
    -- Toggle turbo
    if modType == "turbo" then
        -- Use toggle mod natives
        local hasTurbo = false
        pcall(function()
            hasTurbo = IsToggleModOn(currentVehicle, modSlot)
        end)
        SetVehicleModKit(currentVehicle, 0)
        -- ToggleVehicleMod expects (vehicle, modType, toggle)
        pcall(function()
            ToggleVehicleMod(currentVehicle, modSlot, not hasTurbo)
        end)
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", "Turbo " .. (hasTurbo and "removed" or "added")}
        })
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", "✓ Applied!"}
        })
    
    -- Window tint (0-5, no modification = -1)
    elseif modType == "windowtint" then
        -- window tint native
        SetVehicleModKit(currentVehicle, 0)
        pcall(function()
            SetVehicleWindowTint(currentVehicle, modIndex)
        end)
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", "Window tint applied: Level " .. modIndex}
        })
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", "✓ Applied!"}
        })
    
    -- Xenon headlights (color index)
    elseif modType == "xenon" then
        SetVehicleModKit(currentVehicle, 0)
        if modIndex == -1 then
            -- Turn off xenon
            pcall(function()
                ToggleVehicleMod(currentVehicle, 22, false)
            end)
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Xenon headlights turned off"}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        else
            -- Enable xenon with color
            local ok = false
            pcall(function()
                ToggleVehicleMod(currentVehicle, 22, true)
            end)
            -- Try known xenon color natives in order. Use pcall so missing natives don't error.
            pcall(function()
                if SetVehicleXenonLightColorIndex ~= nil then
                    SetVehicleXenonLightColorIndex(currentVehicle, modIndex)
                    ok = true
                end
            end)
            if not ok then
                pcall(function()
                    -- Some builds expose a generic headlights colour native
                    if SetVehicleHeadlightsColour ~= nil then
                        SetVehicleHeadlightsColour(currentVehicle, modIndex)
                        ok = true
                    end
                end)
            end
            if not ok then
                pcall(function()
                    if SetVehicleHeadlightsColourIndex ~= nil then
                        SetVehicleHeadlightsColourIndex(currentVehicle, modIndex)
                        ok = true
                    end
                end)
            end

            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Xenon headlights " .. (ok and ("color set to " .. modIndex) or "enabled (color API not available on this build)")}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        end
    
    -- License plate style application
    elseif modType == "plate" then
        SetVehicleModKit(currentVehicle, 0)
        -- If -1, attempt to set to stock/default where possible
        if modIndex == -1 then
            pcall(function()
                if SetVehicleNumberPlateTextIndex ~= nil then
                    SetVehicleNumberPlateTextIndex(currentVehicle, -1)
                end
            end)
            TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Plate style set to Stock"} })
            TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })
        else
            local applied = false
            pcall(function()
                if SetVehicleNumberPlateTextIndex ~= nil then
                    SetVehicleNumberPlateTextIndex(currentVehicle, tonumber(modIndex))
                    applied = true
                end
            end)
            if not applied then
                -- Some builds may not expose an index-based native; fallback not available
                -- Optionally, server admins can add SetVehicleNumberPlateText(currentVehicle, text) via a separate UI
            end
            TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Plate style applied"} })
            TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })
        end
    
    -- Neon underglow (color index)
    elseif modType == "neon" then
        SetVehicleModKit(currentVehicle, 0)
        if modIndex == -1 then
            -- Turn off neon
            pcall(function()
                SetVehicleNeonLightEnabled(currentVehicle, 0, false)
                SetVehicleNeonLightEnabled(currentVehicle, 1, false)
                SetVehicleNeonLightEnabled(currentVehicle, 2, false)
                SetVehicleNeonLightEnabled(currentVehicle, 3, false)
            end)
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Neon underglow turned off"}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        else
            -- Enable neon with color on all sides
            pcall(function()
                SetVehicleNeonLightEnabled(currentVehicle, 0, true)
                SetVehicleNeonLightEnabled(currentVehicle, 1, true)
                SetVehicleNeonLightEnabled(currentVehicle, 2, true)
                SetVehicleNeonLightEnabled(currentVehicle, 3, true)
            end)

            -- Get RGB color from the palette
            local col = nil
            for _, entry in ipairs(neonPalette) do
                if entry.index == modIndex then
                    col = entry.rgb
                    break
                end
            end
            if col == nil then
                col = {255,255,255} -- fallback to white
            end

            local applied = false
            local appliedNative = nil
            -- small delay to ensure neon state is active on some runtimes
            Citizen.Wait(60)

            -- Try a list of plausible native names/signatures for neon color
            local neonNativeAttempts = {
                -- name, argsAs = 'rgb'|'index'
                { name = 'SetVehicleNeonLightColor', argsAs = 'rgb' },
                { name = 'SetVehicleNeonLightColour', argsAs = 'rgb' },
                { name = 'SetVehicleNeonLightsColour', argsAs = 'rgb' },
                { name = 'SetVehicleNeonLightsColor', argsAs = 'rgb' },
                { name = 'SetVehicleNeonColour', argsAs = 'rgb' },
                { name = 'SetVehicleNeonColor', argsAs = 'rgb' },
                { name = 'SetVehicleNeonLightColor', argsAs = 'index' },
                { name = 'SetVehicleNeonLightColour', argsAs = 'index' },
                { name = 'SetVehicleNeonLightsColour', argsAs = 'index' },
                { name = 'SetVehicleNeonLightsColor', argsAs = 'index' },
                { name = 'SetVehicleNeonColour', argsAs = 'index' },
                { name = 'SetVehicleNeonColor', argsAs = 'index' }
            }

            for _, attempt in ipairs(neonNativeAttempts) do
                if not applied then
                    local fn = _G[attempt.name]
                    if fn ~= nil then
                        pcall(function()
                            if attempt.argsAs == 'rgb' and col then
                                fn(currentVehicle, col[1], col[2], col[3])
                                applied = true
                                appliedNative = attempt.name
                            elseif attempt.argsAs == 'index' then
                                fn(currentVehicle, modIndex)
                                applied = true
                                appliedNative = attempt.name
                            end
                        end)
                    end
                end
            end

            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Neon underglow " .. (applied and ("color set to " .. modIndex .. " (via " .. appliedNative .. ")") or "enabled (color API not available on this build)")}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        end
    
    -- Livery handling
    elseif modType == "livery" then
        SetVehicleModKit(currentVehicle, 0)
        -- if index == -1, restore to stock (set to 0) where appropriate
        if modIndex == -1 then
            pcall(function() SetVehicleLivery(currentVehicle, 0) end)
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Livery set to Stock"}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        else
            pcall(function() SetVehicleLivery(currentVehicle, modIndex) end)
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "Livery set to variant " .. tostring(modIndex)}
            })
            TriggerEvent('chat:addMessage', {
                color = {0, 255, 0},
                multiline = true,
                args = {"Bennys", "✓ Applied!"}
            })
        end

    -- Standard mod slots
    else
        -- Paint handling: support Primary / Secondary via native GTA color indices
        if modType == 'paint' then
            pcall(function()
                -- modIndex should be: { subtype = 'primary'|'secondary'|'pearlescent'|'wheel', value = <native_color_index> }
                if type(modIndex) == 'table' and modIndex.subtype ~= nil then
                    local subtype = modIndex.subtype
                    local val = tonumber(modIndex.value)
                    
                    if val == nil then
                        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline = true, args = {"Bennys", "Invalid color index"} })
                        cb({ status = 'error', message = 'Invalid color index' })
                        return
                    end
                    
                    if subtype == 'primary' then
                        -- Get current secondary to preserve it
                        local currPrim, currSec = GetVehicleColours(currentVehicle)
                        if currSec == nil then currSec = 0 end
                        
                        -- Set primary color using native color index
                        SetVehicleColours(currentVehicle, val, currSec)
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Primary paint applied"} })
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })

                    elseif subtype == 'secondary' then
                        -- Get current primary to preserve it
                        local currPrim, currSec = GetVehicleColours(currentVehicle)
                        if currPrim == nil then currPrim = 0 end
                        
                        -- Set secondary color using native color index
                        SetVehicleColours(currentVehicle, currPrim, val)
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Secondary paint applied"} })
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })
                    
                    elseif subtype == 'pearlescent' then
                        -- Apply pearlescent color using SetVehicleExtraColours
                        -- Get current extra colours to preserve wheel color
                        local currPearl, currWheel = 0, 0
                        pcall(function()
                            if GetVehicleExtraColours ~= nil then
                                currPearl, currWheel = GetVehicleExtraColours(currentVehicle)
                            end
                        end)
                        if currWheel == nil then currWheel = 0 end
                        
                        -- Set pearlescent while preserving wheel color
                        pcall(function()
                            if SetVehicleExtraColours ~= nil then
                                SetVehicleExtraColours(currentVehicle, val, currWheel)
                            end
                        end)
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Pearlescent applied"} })
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })
                    
                    elseif subtype == 'wheel' then
                        -- Apply wheel color using SetVehicleExtraColours
                        -- Get current extra colours to preserve pearlescent
                        local currPearl, currWheel = 0, 0
                        pcall(function()
                            if GetVehicleExtraColours ~= nil then
                                currPearl, currWheel = GetVehicleExtraColours(currentVehicle)
                            end
                        end)
                        if currPearl == nil then currPearl = 0 end
                        
                        -- Set wheel color while preserving pearlescent
                        pcall(function()
                            if SetVehicleExtraColours ~= nil then
                                SetVehicleExtraColours(currentVehicle, currPearl, val)
                            end
                        end)
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "Wheel color applied"} })
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", "✓ Applied!"} })
                    end
                else
                    -- Legacy/direct index application
                    local idx = tonumber(modIndex)
                    if idx ~= nil and idx >= 0 then
                        -- Apply as primary color
                        local currPrim, currSec = GetVehicleColours(currentVehicle)
                        if currSec == nil then currSec = 0 end
                        SetVehicleColours(currentVehicle, idx, currSec)
                        TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {"Bennys", 'Paint applied: color index ' .. tostring(idx)} })
                    end
                end
            end)
            cb({ status = 'ok' })
            return
        end
        -- Wheels need to set wheel type first when provided to ensure correct variants
        if modType == 'wheels' and wheelType ~= nil then
            pcall(function()
                SetVehicleWheelType(currentVehicle, tonumber(wheelType))
            end)
            Citizen.Wait(120)
            -- refresh mod count for validation
            SetVehicleModKit(currentVehicle, 0)
            local cnt = 0
            pcall(function()
                cnt = GetNumVehicleMods(currentVehicle, modSlot) or 0
            end)
            -- allow -1 for stock, or 0..cnt-1
            if modIndex ~= -1 and (cnt <= 0 or modIndex < 0 or modIndex >= cnt) then
                cb({ status = 'error', message = 'Invalid wheel index' })
                return
            end
        else
            -- allow -1 for stock (where supported by SetVehicleMod)
            if modIndex ~= -1 and (modData.max < 0 or modIndex < 0 or modIndex > modData.max) then
                cb({ status = 'error', message = 'Invalid mod index' })
                return
            end
        end

        SetVehicleModKit(currentVehicle, 0)
        -- if modIndex == -1 we attempt to set to stock by passing -1
        pcall(function()
            SetVehicleMod(currentVehicle, modSlot, modIndex, false)
        end)
        
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", modData.name .. " set to variant " .. modIndex}
        })
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Bennys", "✓ Applied!"}
        })
    end
    
    cb({ status = 'ok' })
end)

-- Close menu on ESC
RegisterKeyMapping('closebennysmenu', 'Close Bennys Menu', 'keyboard', 'ESC')

RegisterCommand('closebennysmenu', function()
    if menuOpen then
        ToggleBennysMenu(false)
    end
end, false)

-- Debug command: probe wheel variant counts for each wheelType and restore original
RegisterCommand('bennys_wheeldbg', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Bennys Debug", "You need to be in a vehicle!"}
        })
        return
    end

    -- Store original wheel type so we can restore it
    local origWheelType = GetVehicleWheelType(vehicle)
    
    SetVehicleModKit(vehicle, 0)
    local modSlot = 23 -- wheels slot
    
    -- probe each wheelType 0..7 by setting and querying
    local results = {}
    for wt = 0, 7 do
        pcall(function()
            SetVehicleWheelType(vehicle, wt)
        end)
        Citizen.Wait(100)
        SetVehicleModKit(vehicle, 0)
        local cnt = 0
        pcall(function()
            cnt = GetNumVehicleMods(vehicle, modSlot) or 0
        end)
        table.insert(results, wt .. ':' .. cnt)
    end
    
    -- restore original wheel type
    pcall(function()
        SetVehicleWheelType(vehicle, origWheelType)
    end)
    Citizen.Wait(100)
    
    local msg = 'Wheel probe (wheelType -> variant count): ' .. table.concat(results, ' | ')
    TriggerEvent('chat:addMessage', {
        color = {0, 255, 200},
        multiline = true,
        args = {"Bennys Debug", msg}
    })
end, false)

-- Diagnostic: inspect extra-colour natives (pearlescent/wheel) and try a quick wheel-index cycle
RegisterCommand('bennys_extracol_dbg', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline=true, args = {'Bennys Debug', 'You need to be in a vehicle!'} })
        return
    end

    local hasGet = (GetVehicleExtraColours ~= nil)
    local hasSet = (SetVehicleExtraColours ~= nil)
    local msg = 'GetVehicleExtraColours=' .. tostring(hasGet) .. ' | SetVehicleExtraColours=' .. tostring(hasSet)
    TriggerEvent('chat:addMessage', { color = {0,200,200}, multiline=true, args = {'Bennys Debug', msg} })

    local origPear, origWheel = nil, nil
    pcall(function()
        if GetVehicleExtraColours ~= nil then
            origPear, origWheel = GetVehicleExtraColours(vehicle)
        end
    end)
    TriggerEvent('chat:addMessage', { color = {0,200,200}, multiline=true, args = {'Bennys Debug', 'Current extra colours: pear=' .. tostring(origPear) .. ' wheel=' .. tostring(origWheel)} })

    if not hasSet then
        TriggerEvent('chat:addMessage', { color = {200,100,0}, multiline=true, args = {'Bennys Debug', 'SetVehicleExtraColours not available on this build; cannot cycle wheel colours.'} })
        return
    end

    -- Quick cycle: attempt a few wheel indices so user can visually observe which indices produce colourful results
    local testIndices = {0, 5, 8, 12}
    local success = false
    for _, idx in ipairs(testIndices) do
        pcall(function()
            if GetVehicleExtraColours ~= nil then
                local curPear, curWheel = GetVehicleExtraColours(vehicle)
                if curPear == nil then curPear = 0 end
                SetVehicleExtraColours(vehicle, curPear, idx)
                success = true
            else
                SetVehicleExtraColours(vehicle, 0, idx)
                success = true
            end
        end)
        Citizen.Wait(500)
    end

    -- restore original
    pcall(function()
        if SetVehicleExtraColours ~= nil then
            local rp = origPear or 0
            local rw = origWheel or 0
            SetVehicleExtraColours(vehicle, rp, rw)
        end
    end)

    TriggerEvent('chat:addMessage', { color = {0,200,0}, multiline=true, args = {'Bennys Debug', success and 'Tried cycling wheel indices; observe the vehicle and report which indices changed appearance.' or 'Failed to set extra colours during test.'} })
end, false)

-- Update vehicle data when menu requests it
RegisterNUICallback('getVehicleData', function(data, cb)
    local catList = {}
    -- Refresh mod counts for the current vehicle to ensure availability is accurate
    if currentVehicle and currentVehicle ~= 0 then
        SetVehicleModKit(currentVehicle, 0)
        for modType, modData in pairs(vehicleModData) do
            local modCount = 0
            pcall(function()
                modCount = GetNumVehicleMods(currentVehicle, modData.slot) or 0
            end)
            vehicleModData[modType].max = (modCount > 0) and (modCount - 1) or -1
        end
    end
    -- Explicit ordering: performance first, then cosmetic
    local performanceOrder = { 'engine', 'brakes', 'suspension', 'turbo' }
    local cosmeticOrder = { 'spoiler', 'frontbumper', 'rearbumper', 'sideskirt', 'exhaust', 'frame', 'grille', 'hood', 'fender', 'rightfender', 'roof', 'paint', 'livery', 'wheels', 'xenon', 'neon', 'plate', 'windowtint', 'horn' }

    local function shouldInclude(modType, modData)
        -- Always include toggles/appearance and neon/xenon/paint and plate
        if modType == 'turbo' or modType == 'windowtint' or modType == 'xenon' or modType == 'neon' or modType == 'paint' or modType == 'plate' then
            return true
        end
        -- livery is model-specific; probe via GetVehicleLiveryCount when available
        if modType == 'livery' then
            SetVehicleModKit(currentVehicle, 0)
            local lc = 0
            pcall(function()
                if GetVehicleLiveryCount ~= nil then lc = GetVehicleLiveryCount(currentVehicle) or 0 end
            end)
            return (lc and lc > 0) or false
        end
        -- ensure modkit is set before querying
        SetVehicleModKit(currentVehicle, 0)
        local modCount = 0
        pcall(function()
            modCount = GetNumVehicleMods(currentVehicle, modData.slot) or 0
        end)
        return (modCount and modCount > 0) or false
    end

    -- add performance mods in order
    for _, modType in ipairs(performanceOrder) do
        local modData = vehicleModData[modType]
        if modData and shouldInclude(modType, modData) then
            table.insert(catList, { id = modType, name = modData.name })
        end
    end

    -- then cosmetic mods in order
    for _, modType in ipairs(cosmeticOrder) do
        local modData = vehicleModData[modType]
        if modData and shouldInclude(modType, modData) then
            table.insert(catList, { id = modType, name = modData.name })
        end
    end

    -- any remaining categories not listed above (fallback)
    for modType, modData in pairs(vehicleModData) do
        local listed = false
        for _, v in ipairs(performanceOrder) do if v == modType then listed = true break end end
        for _, v in ipairs(cosmeticOrder) do if v == modType then listed = true break end end
        if not listed and shouldInclude(modType, modData) then
            table.insert(catList, { id = modType, name = modData.name })
        end
    end

    cb({ categories = catList })
end)

-- Close menu from NUI
RegisterNUICallback('closeMenu', function(data, cb)
    if menuOpen then
        ToggleBennysMenu(false)
    end
    SetNuiFocus(false, false)
    cb({ status = 'ok' })
end)

-- Watch for vehicle changes to avoid stale mod data
-- Track recently spawned vehicles to avoid noisy notifications on re-entry
local spawnNotifyThrottle = {}  -- { [vehNetId] = expiryTime }
local SPAWN_NOTIFY_COOLDOWN = 5000  -- ms; notify only once per vehicle in this window

-- Public export: other resources can call this after spawning a vehicle to show the "Car spawned" notification
function NotifyVehicleSpawned(vehicle)
    if not vehicle or vehicle == 0 then return end
    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    local now = GetGameTimer()
    spawnNotifyThrottle[netId] = now + SPAWN_NOTIFY_COOLDOWN
end

-- Allow other resources to invoke the spawn notification via export
exports('NotifyVehicleSpawned', NotifyVehicleSpawned)

Citizen.CreateThread(function()
    local lastVeh = nil
    while true do
        Citizen.Wait(1000)
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsUsing(ped)
        if vehicle ~= 0 and vehicle ~= lastVeh then
            -- player entered a new vehicle
            lastVeh = vehicle
            currentVehicle = vehicle
            -- update mod counts for new vehicle
            -- Ensure mod kit is set so GetNumVehicleMods returns correct values
            SetVehicleModKit(vehicle, 0)
            for modType, modData in pairs(vehicleModData) do
                local modCount = 0
                pcall(function()
                    modCount = GetNumVehicleMods(vehicle, modData.slot) or 0
                end)
                vehicleModData[modType].max = (modCount > 0) and (modCount - 1) or -1
            end
            -- notify NUI to clear caches and refresh UI
            SendNUIMessage({ type = 'vehicleChanged' })
            
            -- Show "Car spawned" notification if this vehicle was recently created (within throttle window)
            -- This avoids showing the toast repeatedly if the player re-enters the same car
            local netId = NetworkGetNetworkIdFromEntity(vehicle)
            local now = GetGameTimer()
            if spawnNotifyThrottle[netId] and spawnNotifyThrottle[netId] > now then
                -- Vehicle is in the notify window; send a cross-resource notification
                TriggerServerEvent('generalserverrules:notifyRequest', 'Car spawned', 'Your car has spawned', '🚗')
                -- Clear the throttle entry so we don't notify again for this vehicle
                spawnNotifyThrottle[netId] = nil
            end
            
            -- close the menu to avoid applying to wrong vehicle
            if menuOpen then
                ToggleBennysMenu(false)
            end
                    -- Request saved build for this player and apply when entering a vehicle
                    Citizen.CreateThread(function()
                        -- send vehicle model so server can return model-specific builds
                        local modelName = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)) or ''
                        print(('[bennys vehicle enter] requesting build for model=' .. tostring(modelName)))
                        TriggerServerEvent('bennys:requestBuild', { model = modelName })
                    end)
        elseif vehicle == 0 and lastVeh ~= nil then
            -- player left vehicle
            lastVeh = nil
            currentVehicle = nil
            SendNUIMessage({ type = 'vehicleChanged' })
            if menuOpen then
                ToggleBennysMenu(false)
            end
        end
    end
end)

-- Camera control thread - allows free camera rotation while menu is open
Citizen.CreateThread(function()
    local cameraCreated = false
    local camera = nil
    local cameraRot = vector3(0, 0, 0)
    local CAMERA_SPEED = 8.0 -- Increased from 2.0 for faster response
    local CONTROLLER_SPEED = 1.8 -- Controller rotation speed (slower for finer control)
    
    while true do
        Citizen.Wait(0)
        
        if menuOpen and currentVehicle and currentVehicle ~= 0 then
            -- Create camera if it doesn't exist
            if not cameraCreated or not DoesCamExist(camera) then
                local vehicleCoords = GetEntityCoords(currentVehicle)
                camera = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
                SetCamCoord(camera, vehicleCoords.x + 3, vehicleCoords.y + 3, vehicleCoords.z + 1)
                PointCamAtEntity(camera, currentVehicle, 0, 0, 0, true)
                SetCamActive(camera, true)
                RenderScriptCams(true, false, 0, true, true)
                cameraCreated = true
            end
            
            -- Update camera position and rotation with mouse and controller
            local vehicleCoords = GetEntityCoords(currentVehicle)
            
            -- Get mouse movement for camera control
            local mouseX = GetDisabledControlNormal(0, 1) -- Mouse X
            local mouseY = GetDisabledControlNormal(0, 2) -- Mouse Y
            
            -- Get controller right stick movement for camera control
            local controllerX = GetDisabledControlNormal(0, 204) -- Right stick X (camera right)
            local controllerY = GetDisabledControlNormal(0, 205) -- Right stick Y (camera down)
            
            -- Adjust camera rotation based on mouse movement (fast)
            cameraRot = cameraRot + vector3(mouseY * CAMERA_SPEED, 0, mouseX * CAMERA_SPEED)
            
            -- Adjust camera rotation based on controller input (with deadzone)
            local controllerDeadzone = 0.15
            if math.abs(controllerX) > controllerDeadzone then
                cameraRot = cameraRot + vector3(0, 0, controllerX * CONTROLLER_SPEED)
            end
            if math.abs(controllerY) > controllerDeadzone then
                cameraRot = cameraRot + vector3(controllerY * CONTROLLER_SPEED, 0, 0)
            end
            
            -- Clamp vertical rotation to prevent flipping
            if cameraRot.x > 89 then cameraRot = vector3(89, cameraRot.y, cameraRot.z) end
            if cameraRot.x < -89 then cameraRot = vector3(-89, cameraRot.y, cameraRot.z) end
            
            -- Calculate camera position around the vehicle
            local distance = 5.0
            local rotX = math.rad(cameraRot.x)
            local rotZ = math.rad(cameraRot.z)
            
            local camX = vehicleCoords.x + math.sin(rotZ) * math.cos(rotX) * distance
            local camY = vehicleCoords.y + math.cos(rotZ) * math.cos(rotX) * distance
            local camZ = vehicleCoords.z + math.sin(rotX) * distance + 1.0
            
            SetCamCoord(camera, camX, camY, camZ)
            PointCamAtEntity(camera, currentVehicle, 0, 0, 0, true)
        else
            -- Clean up camera when menu closes
            if cameraCreated and DoesCamExist(camera) then
                SetCamActive(camera, false)
                DestroyCam(camera, false)
                RenderScriptCams(false, false, 0, true, true)
                cameraCreated = false
                camera = nil
                cameraRot = vector3(0, 0, 0)
            end
        end
    end
end)


-- Helper to apply a saved build table to a vehicle
local function ApplyBuildToVehicle(vehicle, build)
    if not vehicle or vehicle == 0 or not build then return end
    SetVehicleModKit(vehicle, 0)

    -- Set wheel type first if present
    if build.wheel_type then
        pcall(function() SetVehicleWheelType(vehicle, tonumber(build.wheel_type)) end)
        Citizen.Wait(120)
    end

    for modType, value in pairs(build) do
        if modType == 'wheel_type' then
            -- already handled
        elseif modType == 'turbo' then
            local slot = vehicleModData['turbo'] and vehicleModData['turbo'].slot or 18
            local on = false
            if type(value) == 'table' and value.toggle ~= nil then on = (value.toggle == 1 or value.toggle == true) end
            pcall(function() ToggleVehicleMod(vehicle, slot, on) end)
        elseif modType == 'windowtint' then
            pcall(function() SetVehicleWindowTint(vehicle, tonumber(value)) end)
        elseif modType == 'xenon' then
            -- Robust xenon apply: ensure mod kit set, toggle xenon, wait a short moment, then try multiple color natives
            local enabled = false; local color = nil
            if type(value) == 'table' then enabled = value.enabled; color = value.color else enabled = (value == 1 or value == true) end

            pcall(function() SetVehicleModKit(vehicle, 0) end)
            -- Toggle the xenon mod (slot 22)
            pcall(function() ToggleVehicleMod(vehicle, 22, enabled and true or false) end)
            -- Wait briefly to let the toggle take effect before setting color
            Citizen.Wait(60)

            if enabled then
                local applied = false
                if color ~= nil then
                    local ci = tonumber(color)
                    -- Try common xenon color natives in order
                    pcall(function() if SetVehicleXenonLightColorIndex ~= nil then SetVehicleXenonLightColorIndex(vehicle, ci); applied = true end end)
                    if not applied then pcall(function() if SetVehicleHeadlightsColour ~= nil then SetVehicleHeadlightsColour(vehicle, ci); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleHeadlightsColourIndex ~= nil then SetVehicleHeadlightsColourIndex(vehicle, ci); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleXenonLightColour ~= nil then SetVehicleXenonLightColour(vehicle, ci); applied = true end end) end
                end
                if not applied then
                    -- As a fallback, ensure xenon is enabled even if color API unavailable
                    pcall(function() ToggleVehicleMod(vehicle, 22, true) end)
                end
            else
                pcall(function() ToggleVehicleMod(vehicle, 22, false) end)
            end
        elseif modType == 'neon' then
            local enabled = false; local color = nil
            if type(value) == 'table' then enabled = value.enabled; color = value.color else enabled = (value == 1 or value == true) end
            pcall(function()
                SetVehicleNeonLightEnabled(vehicle, 0, enabled)
                SetVehicleNeonLightEnabled(vehicle, 1, enabled)
                SetVehicleNeonLightEnabled(vehicle, 2, enabled)
                SetVehicleNeonLightEnabled(vehicle, 3, enabled)
            end)
            if enabled and color ~= nil then
                -- Try RGB-style setters first (prefer actual RGB if stored)
                local applied = false
                if type(color) == 'table' then
                    local r,g,b = color[1], color[2], color[3]
                    pcall(function()
                        if SetVehicleNeonLightColor ~= nil then SetVehicleNeonLightColor(vehicle, r, g, b); applied = true end
                    end)
                    if not applied then pcall(function() if SetVehicleNeonLightColour ~= nil then SetVehicleNeonLightColour(vehicle, r, g, b); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonLightsColour ~= nil then SetVehicleNeonLightsColour(vehicle, r, g, b); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonLightsColor ~= nil then SetVehicleNeonLightsColor(vehicle, r, g, b); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonColour ~= nil then SetVehicleNeonColour(vehicle, r, g, b); applied = true end end) end
                end
                -- If not applied and we have a numeric index, try index-style setters
                if not applied and type(color) == 'number' then
                    pcall(function() if SetVehicleNeonLightColor ~= nil then SetVehicleNeonLightColor(vehicle, color); applied = true end end)
                    if not applied then pcall(function() if SetVehicleNeonLightColour ~= nil then SetVehicleNeonLightColour(vehicle, color); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonLightsColour ~= nil then SetVehicleNeonLightsColour(vehicle, color); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonLightsColor ~= nil then SetVehicleNeonLightsColor(vehicle, color); applied = true end end) end
                    if not applied then pcall(function() if SetVehicleNeonColour ~= nil then SetVehicleNeonColour(vehicle, color); applied = true end end) end
                end
            end
        elseif modType == 'plate' then
            -- Apply license plate style index
            if value ~= nil then
                pcall(function()
                    if SetVehicleNumberPlateTextIndex ~= nil then
                        SetVehicleNumberPlateTextIndex(vehicle, tonumber(value))
                    end
                end)
            end
        elseif modType == 'paint' then
            -- Apply paint using native GTA color indices
            if value and type(value) == 'table' then
                local primary = tonumber(value.primary)
                local secondary = tonumber(value.secondary)
                local pearlescent = tonumber(value.pearlescent)
                local wheel = tonumber(value.wheel)
                
                -- Get current colors to preserve what we're not changing
                local currPrim, currSec = nil, nil
                pcall(function()
                    if GetVehicleColours ~= nil then
                        currPrim, currSec = GetVehicleColours(vehicle)
                    end
                end)
                
                -- Use saved values or fall back to current
                if currPrim == nil then currPrim = 0 end
                if currSec == nil then currSec = 0 end
                
                local finalPrim = (primary ~= nil) and primary or currPrim
                local finalSec = (secondary ~= nil) and secondary or currSec
                
                pcall(function()
                    if SetVehicleColours ~= nil then
                        SetVehicleColours(vehicle, finalPrim, finalSec)
                    end
                end)
                
                -- Apply pearlescent and wheel colors if provided
                if pearlescent ~= nil or wheel ~= nil then
                    local currPearl, currWheel = 0, 0
                    pcall(function()
                        if GetVehicleExtraColours ~= nil then
                            currPearl, currWheel = GetVehicleExtraColours(vehicle)
                        end
                    end)
                    
                    local finalPearl = (pearlescent ~= nil) and pearlescent or (currPearl or 0)
                    local finalWheel = (wheel ~= nil) and wheel or (currWheel or 0)
                    
                    pcall(function()
                        if SetVehicleExtraColours ~= nil then
                            SetVehicleExtraColours(vehicle, finalPearl, finalWheel)
                        end
                    end)
                end
            end
        else
            local modData = vehicleModData[modType]
            if modData and modData.slot then
                local slot = modData.slot
                local idx = nil
                if type(value) == 'table' and value.index ~= nil then idx = value.index else idx = value end
                if idx ~= nil then pcall(function() SetVehicleMod(vehicle, slot, tonumber(idx), false) end) end
            end
        end
    end
end


-- Register /save command to capture the current vehicle build and send to server
RegisterCommand('save', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline = true, args = {'Bennys', 'You must be in a vehicle to save its build.'} })
        return
    end

    SetVehicleModKit(vehicle, 0)
    local build = {}
    pcall(function() build.wheel_type = GetVehicleWheelType(vehicle) end)

    for modType, modData in pairs(vehicleModData) do
        local slot = modData.slot
        if modType == 'turbo' then
            local has = false; pcall(function() has = IsToggleModOn(vehicle, slot) end)
            build[modType] = { toggle = has and 1 or 0 }
        elseif modType == 'paint' then
            -- Capture paint using native GTA color indices
            local primary = nil
            local secondary = nil
            local pearlescent = nil
            local wheel = nil
            
            pcall(function()
                if GetVehicleColours ~= nil then
                    local p, s = GetVehicleColours(vehicle)
                    if p ~= nil then primary = tonumber(p) end
                    if s ~= nil then secondary = tonumber(s) end
                end
            end)
            
            pcall(function()
                if GetVehicleExtraColours ~= nil then
                    local pearl, whl = GetVehicleExtraColours(vehicle)
                    if pearl ~= nil then pearlescent = tonumber(pearl) end
                    if whl ~= nil then wheel = tonumber(whl) end
                end
            end)
            
            build[modType] = { primary = primary, secondary = secondary, pearlescent = pearlescent, wheel = wheel }
        elseif modType == 'xenon' then
            local enabled = false; local color = nil
            pcall(function() enabled = IsToggleModOn(vehicle, 22) end)
            -- Try multiple getters for xenon/headlight color index (prefer numeric indices)
            pcall(function()
                if GetVehicleXenonLightColorIndex ~= nil then
                    local ci = GetVehicleXenonLightColorIndex(vehicle)
                    if ci ~= nil then color = tonumber(ci) end
                end
            end)
            if color == nil then
                pcall(function()
                    if GetVehicleHeadlightsColour ~= nil then
                        local ci = GetVehicleHeadlightsColour(vehicle)
                        if ci ~= nil then color = tonumber(ci) end
                    end
                end)
            end
            if color == nil then
                pcall(function()
                    if GetVehicleHeadlightsColourIndex ~= nil then
                        local ci = GetVehicleHeadlightsColourIndex(vehicle)
                        if ci ~= nil then color = tonumber(ci) end
                    end
                end)
            end
            -- fallback: some builds may expose a rgb getter; we don't convert rgb to index here
            build[modType] = { enabled = enabled, color = color }
        elseif modType == 'livery' then
            local liveryIndex = nil
            pcall(function()
                if GetVehicleLivery ~= nil then
                    liveryIndex = GetVehicleLivery(vehicle)
                elseif GetVehicleLiveryIndex ~= nil then
                    liveryIndex = GetVehicleLiveryIndex(vehicle)
                end
            end)
            -- store numeric livery index (may be 0 for default)
            build[modType] = liveryIndex
        elseif modType == 'neon' then
            -- Neon: determine if any side is enabled, then attempt to capture color
            local e0,e1,e2,e3 = false,false,false,false
            pcall(function()
                if IsVehicleNeonLightEnabled ~= nil then
                    e0 = IsVehicleNeonLightEnabled(vehicle,0)
                    e1 = IsVehicleNeonLightEnabled(vehicle,1)
                    e2 = IsVehicleNeonLightEnabled(vehicle,2)
                    e3 = IsVehicleNeonLightEnabled(vehicle,3)
                end
            end)
            local neonEnabled = e0 or e1 or e2 or e3

            -- Try multiple getters to capture neon color. Prefer RGB (r,g,b) if available,
            -- otherwise capture a numeric index if the runtime exposes it.
            local neonColor = nil
            -- Attempt RGB-style getters (capture multiple return values)
            pcall(function()
                if GetVehicleNeonLightsColour ~= nil then
                    local r,g,b = GetVehicleNeonLightsColour(vehicle)
                    if r ~= nil and g ~= nil and b ~= nil then neonColor = { r, g, b } end
                end
            end)
            if neonColor == nil then
                pcall(function()
                    if GetVehicleNeonLightColour ~= nil then
                        local r,g,b = GetVehicleNeonLightColour(vehicle)
                        if r ~= nil and g ~= nil and b ~= nil then neonColor = { r, g, b } end
                    end
                end)
            end
            if neonColor == nil then
                pcall(function()
                    if GetVehicleNeonLightColor ~= nil then
                        local r,g,b = GetVehicleNeonLightColor(vehicle)
                        if r ~= nil and g ~= nil and b ~= nil then neonColor = { r, g, b } end
                    end
                end)
            end
            -- Fallback: try to capture a numeric index if available
            if neonColor == nil then
                pcall(function()
                    if GetVehicleNeonLightColorIndex ~= nil then
                        local idx = GetVehicleNeonLightColorIndex(vehicle)
                        if idx ~= nil then neonColor = tonumber(idx) end
                    end
                end)
            end

            build[modType] = { enabled = neonEnabled, color = neonColor }
        elseif modType == 'windowtint' then
            local tint = nil; pcall(function() if GetVehicleWindowTint ~= nil then tint = GetVehicleWindowTint(vehicle) end end)
            build[modType] = tint
        elseif modType == 'plate' then
            -- Capture license plate style index
            local plateIndex = nil
            pcall(function() if GetVehicleNumberPlateTextIndex ~= nil then plateIndex = GetVehicleNumberPlateTextIndex(vehicle) end end)
            build[modType] = plateIndex
        else
            if slot and slot >= 0 then
                local idx = nil
                pcall(function() idx = GetVehicleMod(vehicle, slot) end)
                build[modType] = idx
            end
        end
    end

    local plate = ''
    pcall(function() plate = GetVehicleNumberPlateText(vehicle) or '' end)
    local model = ''
    pcall(function() model = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)) or '' end)
    local netId = NetworkGetNetworkIdFromEntity(vehicle)

    local payload = { plate = plate, model = model, netId = netId, buildJson = json.encode(build) }
    -- Debug: print captured xenon value so we can verify color was recorded
    pcall(function()
        if build['xenon'] ~= nil then
            print('[bennys /save] xenon = ' .. tostring(json.encode(build['xenon'])))
        else
            print('[bennys /save] xenon = <nil>')
        end
    end)
    -- Debug: print captured performance mods
    pcall(function()
    local perfMods = {'engine', 'brakes', 'suspension', 'turbo'}
        local perfSummary = {}
        for _, modType in ipairs(perfMods) do
            if build[modType] ~= nil then
                table.insert(perfSummary, modType .. '=' .. tostring(build[modType]))
            end
        end
        if #perfSummary > 0 then
            print('[bennys /save] performance mods: ' .. table.concat(perfSummary, ' | '))
        else
            print('[bennys /save] NO performance mods captured')
        end
    end)
    print(('[bennys /save] plate=' .. tostring(plate) .. ' model=' .. tostring(model) .. ' json_len=' .. tostring(string.len(payload.buildJson))))
    TriggerServerEvent('bennys:saveBuild', payload)
end, false)


-- Quick helper: set transmission to stock for the vehicle you're in
RegisterCommand('transmissionstock', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', { color = {255,0,0}, multiline = true, args = {'Bennys', 'You must be in a vehicle to run this command.'} })
        return
    end

    -- slot 13 is the transmission slot on standard FiveM mappings; set to -1 to restore stock
    SetVehicleModKit(vehicle, 0)
    pcall(function()
        SetVehicleMod(vehicle, 13, -1, false)
    end)

    TriggerEvent('chat:addMessage', { color = {0,255,0}, multiline = true, args = {'Bennys', 'Transmission set to stock.'} })
end, false)


-- Receive stored build from server and apply to current vehicle
RegisterNetEvent('bennys:receiveBuild')
AddEventHandler('bennys:receiveBuild', function(buildJson)
    if not buildJson or buildJson == '' or buildJson == nil then return end
    local ok, build = pcall(function() return json.decode(buildJson) end)
    if not ok or not build then return end
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    if vehicle == 0 then return end
    -- Debug: log what we're about to apply (xenon key specifically)
    pcall(function()
        if build['xenon'] ~= nil then
            print('[bennys:receiveBuild] xenon payload = ' .. tostring(json.encode(build['xenon'])))
        else
            print('[bennys:receiveBuild] xenon payload = <nil>')
        end
    end)

    ApplyBuildToVehicle(vehicle, build)
    TriggerEvent('chat:addMessage', { color = {0,200,0}, multiline = true, args = {'Bennys', 'Applied saved build for this vehicle.'} })
end)

-- Receive instruction from server to request a model-specific build
RegisterNetEvent('bennys:clientRequestBuild')
AddEventHandler('bennys:clientRequestBuild', function(model)
    if not model then model = '' end
    TriggerServerEvent('bennys:requestBuild', { model = model })
end)
