--[[
    Bennys Vehicle Customization System - Server
    Refactored for maintainability and centralized database operations

    Key Improvements:
    - Centralized database helper functions
    - Unified identifier management
    - Standardized error handling
    - Reduced code duplication
    - Improved logging consistency
]]

-- ============================================================================
-- CONFIGURATION
-- ============================================================================

local Config = {
    debugDB = true,          -- Enable database debugging
    debugQueries = true,     -- Log all queries
    fallbackIdentifier = true -- Use player:source fallback if no identifier found
}

-- ============================================================================
-- DATABASE HELPER FUNCTIONS
-- ============================================================================

--- Get primary player identifier with fallback
-- @param source number
-- @return string identifier
local function GetPrimaryIdentifier(source)
    if not source or source == 0 then
        return nil
    end

    local identifiers = GetPlayerIdentifiers(source)
    if not identifiers or #identifiers == 0 then
        return Config.fallbackIdentifier and ('player:' .. tostring(source)) or nil
    end

    -- Priority: license > steam > fivem
    for _, id in ipairs(identifiers) do
        if string.find(id, 'license:') then
            return id
        end
    end

    for _, id in ipairs(identifiers) do
        if string.find(id, 'steam:') or string.find(id, 'fivem:') then
            return id
        end
    end

    -- Fallback to first available
    if identifiers[1] and identifiers[1] ~= '' then
        return identifiers[1]
    end

    return Config.fallbackIdentifier and ('player:' .. tostring(source)) or nil
end

--- Log database operation
-- @param operation string
-- @param details string
local function LogDB(operation, details)
    if Config.debugDB then
        print(string.format('[Bennys DB] %s - %s', operation, details))
    end
end

--- Execute database query with error handling
-- @param query string
-- @param params table
-- @param callback function
local function ExecuteDB(query, params, callback)
    if Config.debugQueries then
        LogDB('EXECUTE', string.format('Query: %s | Params: %s', query, json.encode(params or {})))
    end

    exports.oxmysql:execute(query, params, function(result)
        if callback then
            callback(result)
        end
    end)
end

--- Fetch database records with error handling
-- @param query string
-- @param params table
-- @param callback function
local function FetchDB(query, params, callback)
    if Config.debugQueries then
        LogDB('FETCH', string.format('Query: %s | Params: %s', query, json.encode(params or {})))
    end

    exports.oxmysql:fetch(query, params, function(result)
        if callback then
            callback(result)
        end
    end)
end

--- Parse affected rows from various oxmysql return formats
-- @param result mixed
-- @return number affected rows
local function ParseAffectedRows(result)
    if type(result) == 'number' then
        return result
    end

    if type(result) == 'table' then
        -- Try common field names
        if result.affectedRows then
            return tonumber(result.affectedRows)
        end
        if result.affected_rows then
            return tonumber(result.affected_rows)
        end
        if result.affected then
            return tonumber(result.affected)
        end
        if result.insertId then
            return 1 -- Successful insert
        end
    end

    return 0
end

--- Get current database name
-- @param callback function(dbName)
local function GetDatabaseName(callback)
    FetchDB('SELECT DATABASE() AS db', {}, function(result)
        local dbName = (result and result[1] and result[1].db) or '(unknown)'
        if callback then
            callback(dbName)
        end
    end)
end

--- Check if Bennys tables exist
-- @param callback function(exists, tables)
local function CheckBennysTables(callback)
    local query = [[
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME IN ('bennys_vehicle_builds', 'bennys_vehicle_mods')
    ]]

    FetchDB(query, {}, function(result)
        local tables = {}
        local exists = false

        if result and #result > 0 then
            exists = true
            for _, row in ipairs(result) do
                table.insert(tables, row.TABLE_NAME)
            end
        end

        if callback then
            callback(exists, tables)
        end
    end)
end

-- ============================================================================
-- CORE DATABASE OPERATIONS
-- ============================================================================

--- Save complete vehicle build
-- @param source number
-- @param identifier string
-- @param plate string
-- @param model string
-- @param buildJson string
-- @param callback function(success, message)
local function SaveVehicleBuild(source, identifier, plate, model, buildJson, callback)
    LogDB('SAVE BUILD', string.format('Player: %s | Model: %s | Plate: %s', identifier, model, plate))

    -- Debug xenon field if present
    pcall(function()
        local buildTbl = json.decode(buildJson)
        if buildTbl and buildTbl.xenon then
            LogDB('XENON DATA', json.encode(buildTbl.xenon))
        end
    end)

    local query = [[
        INSERT INTO bennys_vehicle_builds (identifier, plate, vehicle_model, build_json, updated_at)
        VALUES (?, ?, ?, ?, FROM_UNIXTIME(?))
        ON DUPLICATE KEY UPDATE
            build_json = VALUES(build_json),
            updated_at = VALUES(updated_at)
    ]]

    local params = { identifier, plate, model, buildJson, os.time() }

    ExecuteDB(query, params, function(result)
        local affected = ParseAffectedRows(result)
        LogDB('SAVE RESULT', string.format('Affected rows: %d', affected))

        if callback then
            if affected > 0 then
                callback(true, 'Vehicle build saved.')
            else
                callback(false, 'No rows affected when saving build.')
            end
        end
    end)
end

--- Load vehicle build
-- @param source number
-- @param identifier string
-- @param model string (optional)
-- @param callback function(buildJson)
local function LoadVehicleBuild(source, identifier, model, callback)
    LogDB('LOAD BUILD', string.format('Player: %s | Model: %s', identifier, model or '(any)'))

    local query = [[SELECT build_json FROM bennys_vehicle_builds WHERE identifier = ?]]
    local params = { identifier }

    if model and model ~= '' then
        query = query .. ' AND vehicle_model = ? LIMIT 1'
        table.insert(params, model)
    else
        query = query .. ' LIMIT 1'
    end

    FetchDB(query, params, function(result)
        if result and result[1] and result[1].build_json then
            LogDB('LOAD SUCCESS', 'Build found for ' .. identifier)
            if callback then
                callback(result[1].build_json)
            end
        else
            -- Try fallback identifier if configured
            if Config.fallbackIdentifier and identifier ~= ('player:' .. tostring(source)) then
                local fallbackId = 'player:' .. tostring(source)
                LogDB('LOAD FALLBACK', 'Trying fallback identifier: ' .. fallbackId)

                local fallbackQuery = [[SELECT build_json FROM bennys_vehicle_builds WHERE identifier = ?]]
                local fallbackParams = { fallbackId }

                if model and model ~= '' then
                    fallbackQuery = fallbackQuery .. ' AND vehicle_model = ? LIMIT 1'
                    table.insert(fallbackParams, model)
                else
                    fallbackQuery = fallbackQuery .. ' LIMIT 1'
                end

                FetchDB(fallbackQuery, fallbackParams, function(fallbackResult)
                    if fallbackResult and fallbackResult[1] and fallbackResult[1].build_json then
                        LogDB('LOAD FALLBACK SUCCESS', 'Build found with fallback')
                        if callback then
                            callback(fallbackResult[1].build_json)
                        end
                    else
                        LogDB('LOAD FAILED', 'No build found for ' .. identifier)
                        if callback then
                            callback(nil)
                        end
                    end
                end)
            else
                LogDB('LOAD FAILED', 'No build found for ' .. identifier)
                if callback then
                    callback(nil)
                end
            end
        end
    end)
end

--- Save individual mod
-- @param source number
-- @param identifier string
-- @param plate string
-- @param model string
-- @param modType string
-- @param modIndex number
-- @param wheelType number (optional)
-- @param callback function(success, message)
local function SaveVehicleMod(source, identifier, plate, model, modType, modIndex, wheelType, callback)
    LogDB('SAVE MOD', string.format('Player: %s | Type: %s | Index: %s', identifier, modType, tostring(modIndex)))

    local query = [[
        INSERT INTO bennys_vehicle_mods (identifier, plate, vehicle_model, mod_type, mod_index, wheel_type, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, FROM_UNIXTIME(?))
        ON DUPLICATE KEY UPDATE
            mod_index = VALUES(mod_index),
            wheel_type = VALUES(wheel_type),
            updated_at = VALUES(updated_at)
    ]]

    local params = { identifier, plate, model, modType, modIndex, wheelType, os.time() }

    ExecuteDB(query, params, function(result)
        local affected = ParseAffectedRows(result)
        LogDB('SAVE MOD RESULT', string.format('Affected rows: %d', affected))

        if callback then
            if affected > 0 then
                callback(true, 'Mod saved to database.')
            else
                callback(false, 'No rows affected when saving mod.')
            end
        end
    end)
end

--- Get all builds for a player
-- @param identifier string
-- @param callback function(builds)
local function GetPlayerBuilds(identifier, callback)
    local query = [[
        SELECT id, vehicle_model, build_json, updated_at
        FROM bennys_vehicle_builds
        WHERE identifier = ?
        ORDER BY updated_at DESC
        LIMIT 50
    ]]

    FetchDB(query, { identifier }, function(result)
        if callback then
            callback(result or {})
        end
    end)
end

-- ============================================================================
-- EVENT HANDLERS
-- ============================================================================

--- Save build event
RegisterServerEvent('bennys:saveBuild')
AddEventHandler('bennys:saveBuild', function(payload)
    local source = source

    -- Validate payload
    if not payload or type(payload) ~= 'table' then
        LogDB('ERROR', 'saveBuild called with invalid payload from source ' .. tostring(source))
        TriggerClientEvent('bennys:saveBuildResult', source, {
            success = false,
            message = 'Invalid payload'
        })
        return
    end

    local identifier = GetPrimaryIdentifier(source)
    if not identifier then
        LogDB('ERROR', 'Could not get identifier for source ' .. tostring(source))
        TriggerClientEvent('bennys:saveBuildResult', source, {
            success = false,
            message = 'Could not identify player'
        })
        return
    end

    local plate = payload.plate or ''
    local model = payload.model or ''
    local buildJson = payload.buildJson or '{}'

    -- Log player identifiers for debugging
    if Config.debugDB then
        local ids = GetPlayerIdentifiers(source) or {}
        LogDB('IDENTIFIERS', 'Source: ' .. tostring(source) .. ' | IDs: ' .. table.concat(ids, ','))
    end

    SaveVehicleBuild(source, identifier, plate, model, buildJson, function(success, message)
        TriggerClientEvent('bennys:saveBuildResult', source, {
            success = success,
            message = message
        })
    end)
end)

--- Request build event
RegisterServerEvent('bennys:requestBuild')
AddEventHandler('bennys:requestBuild', function(payload)
    local source = source

    LogDB('REQUEST BUILD', 'Event fired from source ' .. tostring(source))

    local identifier = GetPrimaryIdentifier(source)
    if not identifier then
        LogDB('ERROR', 'Could not get identifier for source ' .. tostring(source))
        TriggerClientEvent('bennys:receiveBuild', source, nil)
        return
    end

    local model = nil
    if payload and type(payload) == 'table' and payload.model then
        model = tostring(payload.model)
    end

    LoadVehicleBuild(source, identifier, model, function(buildJson)
        TriggerClientEvent('bennys:receiveBuild', source, buildJson)
    end)
end)

--- Save mod event
RegisterServerEvent('bennys:saveMod')
AddEventHandler('bennys:saveMod', function(payload)
    local source = source

    -- Validate payload
    if not payload or type(payload) ~= 'table' then
        LogDB('ERROR', 'saveMod called with invalid payload from source ' .. tostring(source))
        TriggerClientEvent('bennys:saveModResult', source, {
            success = false,
            message = 'Invalid payload'
        })
        return
    end

    local identifier = GetPrimaryIdentifier(source)
    if not identifier then
        LogDB('ERROR', 'Could not get identifier for source ' .. tostring(source))
        TriggerClientEvent('bennys:saveModResult', source, {
            success = false,
            message = 'Could not identify player'
        })
        return
    end

    local plate = payload.plate or ''
    local model = payload.model or ''
    local modType = payload.modType or ''
    local modIndex = payload.modIndex
    local wheelType = payload.wheelType

    SaveVehicleMod(source, identifier, plate, model, modType, modIndex, wheelType, function(success, message)
        TriggerClientEvent('bennys:saveModResult', source, {
            success = success,
            message = message
        })
    end)
end)

-- ============================================================================
-- DIAGNOSTIC COMMANDS
-- ============================================================================

--- Show database info
RegisterCommand('bennys_dbinfo', function(source, args, raw)
    if not Config.debugDB then
        if source ~= 0 then
            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 160, 0},
                args = {'Bennys', 'DB debug disabled on server.'}
            })
        end
        print('bennys_dbinfo: DB debug disabled.')
        return
    end

    GetDatabaseName(function(dbName)
        local message = 'oxmysql DATABASE() -> ' .. dbName
        print('[Bennys] ' .. message)
        if source ~= 0 then
            TriggerClientEvent('chat:addMessage', source, {
                color = {0, 200, 0},
                args = {'Bennys', message}
            })
        end
    end)
end, false)

--- Comprehensive database test
RegisterCommand('bennys_test', function(source, args, raw)
    local function send(msg)
        print('[Bennys Test] ' .. msg)
        if source ~= 0 then
            TriggerClientEvent('chat:addMessage', source, {
                color = {0, 200, 200},
                multiline = true,
                args = {'Bennys Test', msg}
            })
        end
    end

    send('Starting Bennys DB test...')

    -- Step 1: Check database
    GetDatabaseName(function(dbName)
        send('Database: ' .. dbName)

        -- Step 2: Check tables
        CheckBennysTables(function(exists, tables)
            if exists then
                for _, tableName in ipairs(tables) do
                    send('Found table: ' .. tableName)
                end
            else
                send('ERROR: No bennys tables found! Please import the schema.')
                return
            end

            -- Step 3: Test insert
            local testId = 'test:' .. tostring(os.time())
            local query = [[
                INSERT INTO bennys_vehicle_builds (identifier, plate, vehicle_model, build_json, updated_at)
                VALUES (?, ?, ?, ?, FROM_UNIXTIME(?))
                ON DUPLICATE KEY UPDATE updated_at = VALUES(updated_at)
            ]]
            local params = { testId, 'TESTPLATE', 'TESTMODEL', '{"ok":true}', os.time() }

            ExecuteDB(query, params, function(result)
                local affected = ParseAffectedRows(result)
                send('Test insert affected: ' .. tostring(affected))

                -- Step 4: Verify select
                FetchDB('SELECT * FROM bennys_vehicle_builds WHERE identifier = ? LIMIT 1', { testId }, function(rows)
                    if rows and rows[1] then
                        send('Verified row id=' .. tostring(rows[1].id) .. ' identifier=' .. testId)
                        send('TEST PASSED!')
                    else
                        send('ERROR: Insert succeeded but SELECT returned no row!')
                    end
                end)
            end)
        end)
    end)
end, false)

--- Show table schema info
RegisterCommand('bennys_schemainfo', function(source, args, raw)
    if not Config.debugDB then
        if source ~= 0 then
            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 160, 0},
                args = {'Bennys', 'DB debug disabled on server.'}
            })
        end
        print('bennys_schemainfo: DB debug disabled.')
        return
    end

    local query = [[
        SELECT TABLE_NAME, INDEX_NAME,
               GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columns,
               NON_UNIQUE
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME IN ('bennys_vehicle_builds', 'bennys_vehicle_mods')
        GROUP BY TABLE_NAME, INDEX_NAME
        ORDER BY TABLE_NAME, INDEX_NAME
    ]]

    FetchDB(query, {}, function(rows)
        if not rows or #rows == 0 then
            print('bennys_schemainfo: No index info returned.')
            if source ~= 0 then
                TriggerClientEvent('chat:addMessage', source, {
                    color = {255, 100, 100},
                    args = {'Bennys', 'No index info found (tables may be missing).'}
                })
            end
            return
        end

        for _, row in ipairs(rows) do
            local line = string.format('%s -> index=%s columns=%s non_unique=%s',
                tostring(row.TABLE_NAME),
                tostring(row.INDEX_NAME),
                tostring(row.columns),
                tostring(row.NON_UNIQUE))

            print('[Bennys Schema] ' .. line)
            if source ~= 0 then
                TriggerClientEvent('chat:addMessage', source, {
                    color = {0, 200, 200},
                    args = {'Bennys Schema', line}
                })
            end
        end
    end)
end, false)

--- Dump saved builds for player
RegisterCommand('bennys_dump', function(source, args, raw)
    if source == 0 then
        print('bennys_dump: Must be run by a player')
        return
    end

    local identifier = GetPrimaryIdentifier(source)
    if not identifier then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {'Bennys', 'Could not identify player'}
        })
        return
    end

    GetPlayerBuilds(identifier, function(builds)
        if #builds == 0 then
            -- Try fallback
            if Config.fallbackIdentifier then
                local fallbackId = 'player:' .. tostring(source)
                if fallbackId ~= identifier then
                    GetPlayerBuilds(fallbackId, function(fallbackBuilds)
                        if #fallbackBuilds > 0 then
                            TriggerClientEvent('chat:addMessage', source, {
                                color = {255, 200, 0},
                                args = {'Bennys', 'Found builds using fallback identifier'}
                            })
                            for _, build in ipairs(fallbackBuilds) do
                                local preview = tostring(build.build_json)
                                if #preview > 500 then
                                    preview = string.sub(preview, 1, 500) .. '...'
                                end
                                local msg = string.format('id=%s model=%s updated=%s json=%s',
                                    tostring(build.id),
                                    tostring(build.vehicle_model),
                                    tostring(build.updated_at),
                                    preview)
                                TriggerClientEvent('chat:addMessage', source, {
                                    color = {0, 200, 120},
                                    args = {'Bennys Dump', msg}
                                })
                            end
                        else
                            TriggerClientEvent('chat:addMessage', source, {
                                color = {255, 160, 0},
                                args = {'Bennys', 'No saved builds found for your identifier.'}
                            })
                        end
                    end)
                    return
                end
            end

            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 160, 0},
                args = {'Bennys', 'No saved builds found for your identifier.'}
            })
            return
        end

        for _, build in ipairs(builds) do
            local preview = tostring(build.build_json)
            if #preview > 500 then
                preview = string.sub(preview, 1, 500) .. '...'
            end
            local msg = string.format('id=%s model=%s updated=%s json=%s',
                tostring(build.id),
                tostring(build.vehicle_model),
                tostring(build.updated_at),
                preview)

            print('[Bennys Dump] ' .. msg)
            TriggerClientEvent('chat:addMessage', source, {
                color = {0, 200, 120},
                args = {'Bennys Dump', msg}
            })
        end
    end)
end, false)

--- Manual load command for testing
RegisterCommand('bennys_load', function(source, args, raw)
    if source == 0 then
        print('bennys_load: Must be run by a player')
        return
    end

    local model = args[1]
    if not model or model == '' then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 160, 0},
            args = {'Bennys', 'Usage: /bennys_load <modelName>'}
        })
        return
    end

    LogDB('MANUAL LOAD', 'Source: ' .. tostring(source) .. ' Model: ' .. model)
    TriggerClientEvent('bennys:clientRequestBuild', source, model)
end, false)

--- Manual request test
RegisterCommand('bennys_reqtest', function(source, args, raw)
    if source == 0 then
        print('bennys_reqtest: Must be run by a player')
        return
    end

    local model = args[1] or 'T20'
    LogDB('REQUEST TEST', 'Manual trigger for source ' .. tostring(source) .. ' model ' .. model)
    TriggerEvent('bennys:requestBuild', { model = model })
end, false)

-- ============================================================================
-- INITIALIZATION
-- ============================================================================

Citizen.CreateThread(function()
    Citizen.Wait(1000)

    if Config.debugDB then
        GetDatabaseName(function(dbName)
            print(string.format('^2[Bennys]^7 Server loaded | Database: ^3%s^7', dbName))
        end)

        CheckBennysTables(function(exists, tables)
            if exists then
                print('^2[Bennys]^7 Found tables: ' .. table.concat(tables, ', '))
            else
                print('^1[Bennys]^7 WARNING: Bennys tables not found! Please import the schema.')
            end
        end)
    else
        print('^2[Bennys]^7 Server loaded (DB debug disabled)')
    end
end)
