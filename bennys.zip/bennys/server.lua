
-- Minimal server-side Bennys handlers (restored)
-- Requires oxmysql

local dbReady = true
local debugQueryDB = true

local function GetPrimaryIdentifier(source)
    if not source then return nil end
    local ids = GetPlayerIdentifiers(source)
    if not ids or #ids == 0 then return nil end
    -- Try to find license, steam, or fivem identifier
    for _, id in ipairs(ids) do
        if string.find(id, 'license:') or string.find(id, 'steam:') or string.find(id, 'fivem:') then
            return id
        end
    end
    -- Fallback to first available identifier
    if ids[1] and ids[1] ~= '' then
        return ids[1]
    end
    return nil
end

-- Save full build
RegisterServerEvent('bennys:saveBuild')
AddEventHandler('bennys:saveBuild', function(payload)
    local src = source
    if not payload or type(payload) ~= 'table' then
        print('bennys:saveBuild called invalid payload')
        TriggerClientEvent('bennys:saveBuildResult', src, { success = false, message = 'Invalid payload' })
        return
    end

    local identifier = GetPrimaryIdentifier(src) or ('player:' .. tostring(src))
    local plate = payload.plate or ''
    local model = payload.model or ''
    local buildJson = payload.buildJson or '{}'
    local ts = os.time()

    -- Debug: attempt to decode build JSON and log xenon field if present
    pcall(function()
        local ok, buildTbl = pcall(function() return json.decode(buildJson) end)
        if ok and buildTbl and type(buildTbl) == 'table' then
            if buildTbl['xenon'] ~= nil then
                print(('bennys:saveBuild RECEIVED xenon = %s'):format(tostring(json.encode(buildTbl['xenon']))))
            else
                print('bennys:saveBuild RECEIVED xenon = <nil>')
            end
        else
            print('bennys:saveBuild RECEIVED buildJson could not be decoded or empty')
        end
    end)

    -- Log identifiers available for this source to help debug mismatched keys
    local ids = GetPlayerIdentifiers(src) or {}
    local idstr = '(none)'
    if ids and #ids > 0 then idstr = table.concat(ids, ',') end
    print(('bennys:saveBuild called by src=%s identifier_used=%s identifiers=%s model=%s'):format(tostring(src), tostring(identifier), tostring(idstr), tostring(model)))

    if debugQueryDB then
        pcall(function()
            exports.oxmysql:fetch('SELECT DATABASE() AS db', {}, function(res)
                print(('bennys:saveBuild - oxmysql DATABASE() -> %s'):format(tostring((res and res[1] and res[1].db) and res[1].db or '(unknown)')))
            end)
        end)
    end

    local query = [[
        INSERT INTO bennys_vehicle_builds (identifier, plate, vehicle_model, build_json, updated_at)
        VALUES (?, ?, ?, ?, FROM_UNIXTIME(?))
        ON DUPLICATE KEY UPDATE
            build_json = VALUES(build_json),
            updated_at = VALUES(updated_at)
    ]]
    local params = { identifier, plate, model, buildJson, ts }

    exports.oxmysql:execute(query, params, function(affected)
        -- oxmysql may return a number or a result table depending on version/config.
        local affectedCount = nil
        if type(affected) == 'number' then
            affectedCount = affected
        elseif type(affected) == 'table' then
            -- common fields used by different adapters
            if affected.affectedRows ~= nil then affectedCount = tonumber(affected.affectedRows) end
            if not affectedCount and affected.affected_rows ~= nil then affectedCount = tonumber(affected.affected_rows) end
            if not affectedCount and affected.affected ~= nil then affectedCount = tonumber(affected.affected) end
            -- some implementations return insertId when a row was inserted
            if not affectedCount and affected.insertId ~= nil then affectedCount = 1 end
        end

        local affectedDebug = nil
        pcall(function() affectedDebug = json.encode(affected) end)
        print(('bennys:saveBuild - player=%s plate=%s affected=%s'):format(tostring(identifier), tostring(plate), tostring(affectedCount or affectedDebug or tostring(affected))))

        if affectedCount and affectedCount > 0 then
            TriggerClientEvent('bennys:saveBuildResult', src, { success = true, message = 'Vehicle build saved.' })
        else
            TriggerClientEvent('bennys:saveBuildResult', src, { success = false, message = 'No rows affected when saving build.' })
        end
    end)
end)

-- Request build for player
RegisterServerEvent('bennys:requestBuild')
AddEventHandler('bennys:requestBuild', function(payload)
    local src = source
    local identifier = GetPrimaryIdentifier(src) or ('player:' .. tostring(src))

    print(('[bennys:requestBuild] EVENT FIRED - src=%s identifier=%s payload_type=%s'):format(tostring(src), tostring(identifier), type(payload)))

    if debugQueryDB then
        pcall(function()
            exports.oxmysql:fetch('SELECT DATABASE() AS db', {}, function(res)
                print(('bennys:requestBuild - oxmysql DATABASE() -> %s'):format(tostring((res and res[1] and res[1].db) and res[1].db or '(unknown)')))
            end)
        end)
    end

    -- Extract model from payload if provided
    local model = nil
    if payload and type(payload) == 'table' and payload.model then
        model = tostring(payload.model)
    end

    local query = [[SELECT build_json FROM bennys_vehicle_builds WHERE identifier = ?]]
    local params = { identifier }
    
    if model and model ~= '' then
        print(('[bennys:requestBuild] identifier=%s requested_model=%s'):format(tostring(identifier), tostring(model)))
        query = query .. ' AND vehicle_model = ? LIMIT 1'
        table.insert(params, model)
    else
        print(('[bennys:requestBuild] identifier=%s NO_MODEL_PROVIDED - will return first build'):format(tostring(identifier)))
        query = query .. ' LIMIT 1'
    end
    
    exports.oxmysql:fetch(query, params, function(result)
        if result and result[1] and result[1].build_json then
            print(('[bennys:requestBuild] SENDING BUILD to client for identifier=%s'):format(tostring(identifier)))
            TriggerClientEvent('bennys:receiveBuild', src, result[1].build_json)
        else
            -- If no result found with primary identifier, try fallback 'player:<src>' key
            if identifier ~= ('player:' .. tostring(src)) then
                print(('[bennys:requestBuild] NO BUILD FOUND for primary identifier=%s, trying fallback'):format(tostring(identifier)))
                local fallback = 'player:' .. tostring(src)
                local fallback_query = [[SELECT build_json FROM bennys_vehicle_builds WHERE identifier = ?]]
                local fallback_params = { fallback }
                if model and model ~= '' then
                    fallback_query = fallback_query .. ' AND vehicle_model = ? LIMIT 1'
                    table.insert(fallback_params, model)
                else
                    fallback_query = fallback_query .. ' LIMIT 1'
                end
                exports.oxmysql:fetch(fallback_query, fallback_params, function(fallback_result)
                    if fallback_result and fallback_result[1] and fallback_result[1].build_json then
                        print(('[bennys:requestBuild] SENDING BUILD from fallback identifier=%s to client'):format(tostring(fallback)))
                        TriggerClientEvent('bennys:receiveBuild', src, fallback_result[1].build_json)
                    else
                        print(('[bennys:requestBuild] NO BUILD FOUND for either identifier (primary or fallback)'):format())
                        TriggerClientEvent('bennys:receiveBuild', src, nil)
                    end
                end)
            else
                print(('[bennys:requestBuild] NO BUILD FOUND for identifier=%s'):format(tostring(identifier)))
                TriggerClientEvent('bennys:receiveBuild', src, nil)
            end
        end
    end)
end)

-- Helper command for testing: request build for specific model
RegisterCommand('bennys_load', function(source, args, raw)
    local src = source
    if src == 0 then
        print('bennys_load requires a player to run it')
        return
    end
    local model = args[1]
    if not model or model == '' then
        TriggerClientEvent('chat:addMessage', src, { color = {255,160,0}, args = {'Bennys', 'Usage: /bennys_load <modelName>'} })
        return
    end
    -- forward to the player who executed the command (their client will request the model)
    print(('[bennys_load] manual trigger for src=%s model=%s'):format(tostring(src), tostring(model)))
    TriggerClientEvent('bennys:clientRequestBuild', src, model)
end, false)


-- Diagnostic: manually trigger requestBuild on server to test event handler
RegisterCommand('bennys_reqtest', function(source, args, raw)
    local src = source
    if src == 0 then
        print('bennys_reqtest must be run by a player')
        return
    end
    local model = args[1] or 'T20'
    print(('[bennys_reqtest] manually triggering server event for src=%s model=%s'):format(tostring(src), tostring(model)))
    -- Directly trigger the event handler logic for testing
    TriggerEvent('bennys:requestBuild', { model = model })
end, false)

-- Save individual mod (minimal)
RegisterServerEvent('bennys:saveMod')
AddEventHandler('bennys:saveMod', function(payload)
    local src = source
    if not payload or type(payload) ~= 'table' then
        TriggerClientEvent('bennys:saveModResult', src, { success = false, message = 'Invalid payload' })
        return
    end
    local identifier = GetPrimaryIdentifier(src) or ('player:' .. tostring(src))
    local plate = payload.plate or ''
    local vehicleModel = payload.model or ''
    local modType = payload.modType or ''
    local modIndex = payload.modIndex
    local wheelType = payload.wheelType
    local ts = os.time()

    if debugQueryDB then
        pcall(function()
            exports.oxmysql:fetch('SELECT DATABASE() AS db', {}, function(res)
                print(('bennys:saveMod - oxmysql DATABASE() -> %s'):format(tostring((res and res[1] and res[1].db) and res[1].db or '(unknown)')))
            end)
        end)
    end

    local query = [[
        INSERT INTO bennys_vehicle_mods (identifier, plate, vehicle_model, mod_type, mod_index, wheel_type, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, FROM_UNIXTIME(?))
        ON DUPLICATE KEY UPDATE mod_index = VALUES(mod_index), wheel_type = VALUES(wheel_type), updated_at = VALUES(updated_at)
    ]]
    local params = { identifier, plate, vehicleModel, modType, modIndex, wheelType, ts }

    exports.oxmysql:execute(query, params, function(affected)
        local affectedCount = nil
        if type(affected) == 'number' then
            affectedCount = affected
        elseif type(affected) == 'table' then
            if affected.affectedRows ~= nil then affectedCount = tonumber(affected.affectedRows) end
            if not affectedCount and affected.affected_rows ~= nil then affectedCount = tonumber(affected.affected_rows) end
            if not affectedCount and affected.affected ~= nil then affectedCount = tonumber(affected.affected) end
            if not affectedCount and affected.insertId ~= nil then affectedCount = 1 end
        end

        local affectedDebug = nil
        pcall(function() affectedDebug = json.encode(affected) end)
        print(('bennys:saveMod - player=%s plate=%s modType=%s modIndex=%s wheelType=%s affected=%s'):format(tostring(identifier), tostring(plate), tostring(modType), tostring(modIndex), tostring(wheelType), tostring(affectedCount or affectedDebug or tostring(affected))))

        if affectedCount and affectedCount > 0 then
            TriggerClientEvent('bennys:saveModResult', src, { success = true, message = 'Mod saved to database.' })
        else
            TriggerClientEvent('bennys:saveModResult', src, { success = false, message = 'No rows affected when saving mod (check DB).' })
        end
    end)
end)

-- Bennys DB info command
RegisterCommand('bennys_dbinfo', function(source, args, raw)
    local src = source
    if not debugQueryDB then
        if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,160,0}, args = {'Bennys', 'DB debug disabled on server.'} }) end
        print('bennys_dbinfo: DB debug disabled on server.')
        return
    end

    pcall(function()
        exports.oxmysql:fetch('SELECT DATABASE() AS db', {}, function(res)
            local dbname = (res and res[1] and res[1].db) and res[1].db or '(unknown)'
            print(('bennys_dbinfo - oxmysql DATABASE() -> %s'):format(tostring(dbname)))
            if src ~= 0 then
                TriggerClientEvent('chat:addMessage', src, { color = {0,200,0}, args = {'Bennys', 'oxmysql DATABASE() -> ' .. tostring(dbname)} })
            end
        end)
    end)
end, false)


-- Comprehensive test command: checks DB, tables, and does a test insert/select
RegisterCommand('bennys_test', function(source, args, raw)
    local src = source
    local function send(msg)
        print('[bennys_test] ' .. msg)
        if src ~= 0 then
            TriggerClientEvent('chat:addMessage', src, { color = {0,200,200}, multiline = true, args = {'Bennys Test', msg} })
        end
    end

    send('Starting Bennys DB test...')

    -- Step 1: DATABASE()
    pcall(function()
        exports.oxmysql:fetch('SELECT DATABASE() AS db', {}, function(res)
            local dbname = (res and res[1] and res[1].db) and res[1].db or '(unknown)'
            send('oxmysql DATABASE() -> ' .. tostring(dbname))

            -- Step 2: check tables exist in current DB
            exports.oxmysql:fetch([[
                SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('bennys_vehicle_builds', 'bennys_vehicle_mods')
            ]], {}, function(tables)
                if tables and #tables > 0 then
                    for _, t in ipairs(tables) do
                        send('Found table: ' .. tostring(t.TABLE_NAME))
                    end
                else
                    send('No bennys tables found in current DB. Please import the schema.')
                end

                -- Step 3: attempt a test insert
                local ident = 'test:' .. tostring(os.time())
                local q = [[
                    INSERT INTO bennys_vehicle_builds (identifier, plate, vehicle_model, build_json, updated_at)
                    VALUES (?, ?, ?, ?, FROM_UNIXTIME(?))
                    ON DUPLICATE KEY UPDATE updated_at = VALUES(updated_at)
                ]]
                local params = { ident, 'TESTPLATE', 'TESTMODEL', '{"ok":true}', os.time() }
                exports.oxmysql:execute(q, params, function(affected)
                    send('Test insert affected: ' .. tostring(affected))
                    -- verify select
                    exports.oxmysql:fetch('SELECT * FROM bennys_vehicle_builds WHERE identifier = ? LIMIT 1', { ident }, function(res2)
                        if res2 and res2[1] then
                            send('Verified inserted row id=' .. tostring(res2[1].id) .. ' identifier=' .. tostring(res2[1].identifier))
                        else
                            send('Insert reported affected>0 but SELECT returned no row or table missing.')
                        end
                    end)
                end)
            end)
        end)
    end)
end, false)


-- Show index/unique key information for bennys tables
RegisterCommand('bennys_schemainfo', function(source, args, raw)
    local src = source
    if not debugQueryDB then
        if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,160,0}, args = {'Bennys', 'DB debug disabled on server.'} }) end
        print('bennys_schemainfo: DB debug disabled on server.')
        return
    end

    pcall(function()
        local q = [[
            SELECT TABLE_NAME, INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columns, NON_UNIQUE
            FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('bennys_vehicle_builds', 'bennys_vehicle_mods')
            GROUP BY TABLE_NAME, INDEX_NAME
            ORDER BY TABLE_NAME, INDEX_NAME
        ]]
        exports.oxmysql:fetch(q, {}, function(rows)
            if not rows or #rows == 0 then
                print('bennys_schemainfo: No index info returned (tables may be missing).')
                if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,100,100}, args = {'Bennys', 'No index info found (tables may be missing).'} }) end
                return
            end
            for _, r in ipairs(rows) do
                local line = ('%s -> index=%s columns=%s non_unique=%s'):format(tostring(r.TABLE_NAME), tostring(r.INDEX_NAME), tostring(r.columns), tostring(r.NON_UNIQUE))
                print('[bennys_schemainfo] ' .. line)
                if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {0,200,200}, multiline = false, args = {'Bennys Schema', line} }) end
            end
        end)
    end)
end, false)


-- Dump saved builds for the calling player (shows model and a short preview of build_json)
RegisterCommand('bennys_dump', function(source, args, raw)
    local src = source
    local identifier = GetPrimaryIdentifier(src) or ('player:' .. tostring(src))
    pcall(function()
        exports.oxmysql:fetch('SELECT id, vehicle_model, build_json, updated_at FROM bennys_vehicle_builds WHERE identifier = ? ORDER BY updated_at DESC LIMIT 50', { identifier }, function(rows)
            if not rows or #rows == 0 then
                -- Try fallback key which may have been used if identifiers were not available during save
                local fallback = 'player:' .. tostring(src)
                if fallback ~= identifier then
                    exports.oxmysql:fetch('SELECT id, vehicle_model, build_json, updated_at FROM bennys_vehicle_builds WHERE identifier = ? ORDER BY updated_at DESC LIMIT 50', { fallback }, function(rows2)
                        if rows2 and #rows2 > 0 then
                            if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,200,0}, args = {'Bennys', 'No rows for primary identifier, but found rows for fallback identifier player:<id>'} }) end
                            for _, r in ipairs(rows2) do
                                local preview = tostring(r.build_json)
                                if #preview > 500 then preview = string.sub(preview,1,500) .. '...' end
                                local msg = ('id=%s model=%s updated=%s json=%s'):format(tostring(r.id), tostring(r.vehicle_model), tostring(r.updated_at), preview)
                                print('[bennys_dump-fallback] ' .. msg)
                                if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {0,200,120}, multiline = false, args = {'Bennys Dump', msg} }) end
                            end
                            return
                        else
                            if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,160,0}, args = {'Bennys', 'No saved builds found for your identifier or fallback.'} }) end
                            print('bennys_dump: no rows for ' .. tostring(identifier) .. ' or fallback ' .. tostring(fallback))
                            return
                        end
                    end)
                    return
                else
                    if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {255,160,0}, args = {'Bennys', 'No saved builds found for your identifier.'} }) end
                    print('bennys_dump: no rows for ' .. tostring(identifier))
                    return
                end
            end
            for _, r in ipairs(rows) do
                local preview = tostring(r.build_json)
                if #preview > 500 then preview = string.sub(preview,1,500) .. '...' end
                local msg = ('id=%s model=%s updated=%s json=%s'):format(tostring(r.id), tostring(r.vehicle_model), tostring(r.updated_at), preview)
                print('[bennys_dump] ' .. msg)
                if src ~= 0 then TriggerClientEvent('chat:addMessage', src, { color = {0,200,120}, multiline = false, args = {'Bennys Dump', msg} }) end
            end
        end)
    end)
end, false)
